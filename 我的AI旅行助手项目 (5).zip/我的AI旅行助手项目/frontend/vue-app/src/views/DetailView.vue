<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import request from '../utils/request'

const router = useRouter()
const route = useRoute()

const activeDays = ref([1])
const toggleDay = (day) => {
  if (activeDays.value.includes(day)) {
    activeDays.value = activeDays.value.filter(d => d !== day)
  } else {
    activeDays.value.push(day)
  }
}

const weatherTip = ref('今日小雨转阴 18~23°C，AI已调整<strong>室内景点优先</strong>')
const regenerate = () => {
  weatherTip.value = '⏳ AI 规划中…'
  setTimeout(() => {
    const tips = [
      '今日小雨转阴 18~23°C，AI已调整<strong>室内景点优先</strong>',
      '明日转晴 16~26°C，AI已将长城行程调整至<strong>上午出发</strong>',
      '空气质量优，AI已为你加入<strong>景山日落观景</strong>环节'
    ]
    weatherTip.value = tips[Math.floor(Math.random() * tips.length)]
  }, 800)
}

// 👇 新增：从数据库获取当前行程数据
const trip = ref({ title: '加载中...', destination: '', startDate: '', endDate: '' })

onMounted(async () => {
  const tripId = route.query.id
  if (tripId) {
    try {
      const res = await request.get(`/trips/${tripId}`)
      if (res.code === 200) {
        trip.value = res.data
      }
    } catch (error) {
      console.error('获取行程失败', error)
    }
  }
})
</script>

<template>
  <div class="min-h-screen bg-sky-50/70">
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <button @click="router.push('/home')" class="flex items-center gap-1.5 text-sky-600 hover:text-sky-500 font-medium transition">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
          返回首页
        </button>
        <span class="font-bold text-slate-700">行程详情</span>
      </div>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-8 flex flex-col lg:flex-row gap-6 items-stretch">
      <section class="lg:w-3/5 relative rounded-2xl overflow-hidden border border-slate-200 shadow-md min-h-[70vh]" style="background: linear-gradient(135deg,#e2e8f0 0%,#cbd5e1 100%);">
        <div class="absolute inset-0 opacity-30" style="background-image:linear-gradient(#94a3b8 1px,transparent 1px),linear-gradient(90deg,#94a3b8 1px,transparent 1px);background-size:48px 48px;"></div>
        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 600 600" preserveAspectRatio="none">
          <path d="M120,180 C200,120 300,260 380,220 S480,380 420,460" fill="none" stroke="#38bdf8" stroke-width="4" stroke-dasharray="10 8" stroke-linecap="round"/>
        </svg>
        <div class="absolute" style="left:20%;top:30%">
          <span class="absolute -inset-3 bg-sky-400/40 rounded-full animate-ping"></span>
          <span class="relative block w-5 h-5 bg-sky-500 rounded-full border-2 border-white shadow-lg"></span>
          <span class="absolute left-6 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">📍 故宫博物院</span>
        </div>
        <div class="absolute" style="left:63%;top:37%">
          <span class="relative block w-4 h-4 bg-amber-400 rounded-full border-2 border-white shadow"></span>
          <span class="absolute left-5 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">🦆 烤鸭店</span>
        </div>
        <div class="absolute" style="left:70%;top:77%">
          <span class="relative block w-4 h-4 bg-emerald-500 rounded-full border-2 border-white shadow"></span>
          <span class="absolute left-5 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">⛰️ 景山公园</span>
        </div>
        <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <svg class="w-14 h-14 text-slate-400/70 mb-3" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
          <p class="text-slate-500 text-lg font-medium tracking-widest">地图加载区</p>
        </div>
        <div class="absolute right-4 top-4 flex flex-col bg-white rounded-lg shadow-md overflow-hidden">
          <button class="w-9 h-9 text-slate-600 hover:bg-sky-50 font-bold transition">＋</button>
          <div class="h-px bg-slate-100"></div>
          <button class="w-9 h-9 text-slate-600 hover:bg-sky-50 font-bold transition">－</button>
        </div>
        <div class="absolute left-4 bottom-4 bg-white/90 backdrop-blur rounded-lg shadow px-4 py-2.5 text-xs text-slate-600">
          <p class="font-semibold text-slate-800 mb-1">Day 1 路线</p>
          <p class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-sky-500"></span>故宫 → <span class="w-2 h-2 rounded-full bg-amber-400"></span>烤鸭 → <span class="w-2 h-2 rounded-full bg-emerald-500"></span>景山</p>
        </div>
      </section>

      <section class="lg:w-2/5 bg-white rounded-2xl shadow-md border border-sky-100 p-6 flex flex-col">
        <div class="flex items-start justify-between">
          <div>
           <!-- 原来写死的标题 -->
<!-- <h2 class="text-2xl font-bold text-slate-800">北京三日游 ...</h2> -->

<!-- 👇 改成动态的 -->
<h2 class="text-2xl font-bold text-slate-800">{{ trip.title }} <span class="bg-gradient-to-r from-sky-500 to-blue-500 bg-clip-text text-transparent text-lg">（AI定制）</span></h2>
<p class="text-xs text-slate-400 mt-1">
  {{ trip.startDate ? trip.startDate.substring(0, 10) : '' }} 至 
  {{ trip.endDate ? trip.endDate.substring(0, 10) : '' }} · 2人出行 · 已为你节省 ¥320
</p>
          </div>
          <span class="shrink-0 px-2.5 py-1 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold">AI 已优化</span>
        </div>

        <div class="mt-4 flex items-center gap-2.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 text-sky-700 text-sm rounded-xl px-4 py-3">
          <span class="text-lg">🌦️</span>
          <span v-html="weatherTip"></span>
        </div>

        <div class="mt-5 space-y-3 flex-1">
          <div class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
            <button @click="toggleDay(1)" class="w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r from-sky-500 to-blue-500 text-white">
              <span class="font-semibold flex items-center gap-2">Day 1 · 皇城文化线 <span class="text-xs bg-white/20 px-2 py-0.5 rounded-full">3 个地点</span></span>
              <span class="acc-arrow" :class="{'rotate-180': activeDays.includes(1)}">▾</span>
            </button>
            <div class="acc-body" :style="{ maxHeight: activeDays.includes(1) ? '500px' : '0px' }">
              <ul class="divide-y divide-sky-50">
                <li class="px-5 py-4 flex items-center gap-4">
                  <span class="text-sky-600 font-mono font-bold w-14">09:00</span>
                  <div class="flex-1"><p class="font-medium text-slate-800">故宫博物院</p><p class="text-xs text-slate-400">建议游览 3 小时 · 室内优先</p></div>
                  <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥60</span>
                </li>
                <li class="px-5 py-4 flex items-center gap-4">
                  <span class="text-sky-600 font-mono font-bold w-14">12:00</span>
                  <div class="flex-1"><p class="font-medium text-slate-800">烤鸭午餐（四季民福）</p><p class="text-xs text-slate-400">人均 ¥120 · 已取号</p></div>
                  <span class="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-lg">美食</span>
                </li>
                <li class="px-5 py-4 flex items-center gap-4">
                  <span class="text-sky-600 font-mono font-bold w-14">14:00</span>
                  <div class="flex-1"><p class="font-medium text-slate-800">景山公园</p><p class="text-xs text-slate-400">登顶俯瞰故宫全景</p></div>
                  <span class="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">¥2</span>
                </li>
              </ul>
            </div>
          </div>

          <div class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
            <button @click="toggleDay(2)" class="w-full flex items-center justify-between px-5 py-4 bg-white hover:bg-sky-50 text-slate-700">
              <span class="font-semibold">Day 2 · 长城雄关线 <span class="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">2 个地点</span></span>
              <span class="acc-arrow text-slate-400" :class="{'rotate-180': activeDays.includes(2)}">▾</span>
            </button>
            <div class="acc-body" :style="{ maxHeight: activeDays.includes(2) ? '500px' : '0px' }">
              <ul class="divide-y divide-sky-50">
                <li class="px-5 py-4 flex items-center gap-4">
                  <span class="text-sky-600 font-mono font-bold w-14">08:00</span>
                  <div class="flex-1"><p class="font-medium text-slate-800">八达岭长城</p><p class="text-xs text-slate-400">缆车上下</p></div>
                  <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥40</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="mt-6 flex gap-4">
          <button @click="regenerate" class="flex-1 py-3.5 rounded-xl border-2 border-sky-400 text-sky-600 font-semibold hover:bg-sky-50">🔄 重新生成</button>
          <button @click="alert('已为你打开导航')" class="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-500 text-white font-semibold">🧭 一键导航</button>
        </div>
      </section>
    </main>
  </div>
</template>