package com.aistudy.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.aistudy.backend.entity.Trip;

public interface TripService extends IService<Trip> {
}