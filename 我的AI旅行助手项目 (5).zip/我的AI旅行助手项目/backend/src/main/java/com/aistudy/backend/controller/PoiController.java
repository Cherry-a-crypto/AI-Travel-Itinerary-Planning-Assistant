package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.service.PoiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/pois")
public class PoiController {

    @Autowired
    private PoiService poiService;

    @GetMapping("/list")
    public Result<List<Poi>> list() {
        return Result.success(poiService.list());
    }
}