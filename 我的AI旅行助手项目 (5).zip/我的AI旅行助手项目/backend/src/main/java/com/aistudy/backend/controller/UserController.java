package com.aistudy.backend.controller;

import com.aistudy.backend.common.JwtUtils;
import com.aistudy.backend.common.Result;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtils jwtUtils;

    // 👇 注入密码加密器
    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. 查询所有用户
    @GetMapping("/list")
    public Result<List<User>> list() {
        List<User> list = userService.list();
        return Result.success(list);
    }

    // 👇 这个就是 addUser 方法（注册）
    @PostMapping("/add")
    public Result<Boolean> addUser(@Valid @RequestBody User user) {
        // 1. 把前端传来的明文密码加密
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        // 2. 存入数据库
        boolean success = userService.save(user);
        return Result.success(success);
    }

    // 3. 修改用户
    @PutMapping("/update")
    public Result<Boolean> updateUser(@Valid @RequestBody User user) {
        boolean success = userService.updateById(user);
        return Result.success(success);
    }

    // 4. 删除用户
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteUser(@PathVariable Long id) {
        boolean success = userService.removeById(id);
        return Result.success(success);
    }

    // 👇 这个就是 login 方法（登录）
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody User user) {
        // 去数据库里按用户名查
        User dbUser = userService.lambdaQuery()
                .eq(User::getUsername, user.getUsername())
                .one();

        if (dbUser == null) {
            return Result.error("用户不存在");
        }

        // 👇 密码比对逻辑（兼容处理）
        boolean isPasswordMatch = false;
        // 如果数据库里存的是 $2a$ 开头的（说明是用 Bcrypt 加密过的）
        if (dbUser.getPasswordHash().startsWith("$2a$")) {
            isPasswordMatch = passwordEncoder.matches(user.getPasswordHash(), dbUser.getPasswordHash());
        } else {
            // 如果是明文（比如你以前存的 admin），直接比对
            isPasswordMatch = dbUser.getPasswordHash().equals(user.getPasswordHash());
        }

        if (!isPasswordMatch) {
            return Result.error("密码错误");
        }

        // 密码正确，生成 JWT Token
        String token = jwtUtils.generateToken(dbUser.getUsername());

        Map<String, Object> data = new HashMap<>();
        data.put("token", token);

        // 把密码抹掉再返回
        dbUser.setPasswordHash(null);
        data.put("userInfo", dbUser);

        return Result.success(data);
    }
}