package com.aistudy.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.mapper.TripMapper;
import com.aistudy.backend.service.TripService;
import org.springframework.stereotype.Service;

@Service
public class TripServiceImpl extends ServiceImpl<TripMapper, Trip> implements TripService {
}