package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.TripService;
import com.aistudy.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    @Autowired
    private TripService tripService;

    @Autowired
    private UserService userService;

    private User getCurrentUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userService.lambdaQuery().eq(User::getUsername, username).one();
    }

    @PostMapping("/create")
    public Result<Trip> createTrip(@RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) return Result.error("用户未登录");

        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false);

        tripService.save(trip);

        // 注意：这里把 AI 生成去掉了，直接保存行程
        return Result.success(trip);
    }

    @GetMapping("/list")
    public Result<List<Trip>> list() {
        User currentUser = getCurrentUser();
        if (currentUser == null) return Result.error("用户未登录");
        return Result.success(tripService.lambdaQuery().eq(Trip::getUserId, currentUser.getId()).list());
    }

    @GetMapping("/{id}")
    public Result<Trip> getTripById(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) return Result.error("行程不存在");

        User currentUser = getCurrentUser();
        if (currentUser != null && !trip.getUserId().equals(currentUser.getId())) {
            return Result.error("无权访问他人的行程！");
        }
        return Result.success(trip);
    }
}