package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.TripService;
import com.aistudy.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    @Autowired
    private UserService userService;

    @Autowired
    private TripService tripService;

    @Autowired
    private AiTripService aiTripService;

    // 获取当前登录用户的方法
    private User getCurrentUser() {
        try {
            String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return userService.lambdaQuery().eq(User::getUsername, username).one();
        } catch (Exception e) {
            return null;
        }
    }

    // 1. 根据 ID 查询行程详情
    @GetMapping("/{id}")
    public Result<Trip> getTripById(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip != null) {
            return Result.success(trip);
        }
        return Result.error("行程不存在或已被删除");
    }

    // 2. 创建行程（注意：这里不调 AI 了，光建行程，秒回！）
    @PostMapping("/create")
    public Result<Object> createTrip(@RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) {
            return Result.error("未登录或登录已过期");
        }

        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false);
        trip.setPoiIds(dto.getPoiIds());

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip); // 只把存好数据库的 trip 返给前端拿 ID
            return Result.success(resultData);
        } else {
            return Result.error("创建行程失败，请稍后重试");
        }
    }

    // 👇 3. 新增：流式生成 AI 接口（前端详情页调这个！）
    @GetMapping(value = "/stream/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamAiText(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) {
            return Flux.just("行程不存在");
        }
        return aiTripService.streamItinerary(trip);
    }
}