package com.aistudy.backend.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;

@Data // 注意：如果你没装 Lombok，手动 Alt+Insert 生成 Getter/Setter
public class TripCreateDTO {
    private String title;
    private String destination;
    private Date startDate;
    private Date endDate;
    private BigDecimal budget;
    // 注意：这里没有 id，没有 userId，没有 isPublic！
    // 这些敏感字段由后端自己控制，前端无权干涉！
}