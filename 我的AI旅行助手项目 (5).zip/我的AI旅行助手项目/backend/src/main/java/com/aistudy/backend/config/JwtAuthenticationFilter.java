package com.aistudy.backend.config;

import com.aistudy.backend.common.JwtUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 👇 终极打印，只要请求过来，一定会打印这句
        System.out.println("========== 拦截器进来了！ ==========");

        String authHeader = request.getHeader("Authorization");
        System.out.println("【拦截器】收到的 Header 是: [" + authHeader + "]");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);

            if (jwtUtils.validateToken(token)) {
                String username = jwtUtils.getUsernameFromToken(token);
                System.out.println("【拦截器】Token 验证成功，用户: " + username);

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(username, null, Collections.emptyList());
                SecurityContextHolder.getContext().setAuthentication(authentication);
            } else {
                System.out.println("【拦截器】Token 验证失败，无效或过期！");
            }
        } else {
            System.out.println("【拦截器】请求未携带有效的 Authorization 头！");
        }

        // 放行请求
        filterChain.doFilter(request, response);
    }
}