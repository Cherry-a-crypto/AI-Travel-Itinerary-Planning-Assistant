package com.aistudy.backend.service.impl;

import com.aistudy.backend.entity.ItineraryItem;
import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.TripDay;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.ItineraryItemService;
import com.aistudy.backend.service.PoiService;
import com.aistudy.backend.service.TripDayService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class AiTripServiceImpl implements AiTripService {

    // 我们先把基础框架搭好，下一步再把变量放进来
}