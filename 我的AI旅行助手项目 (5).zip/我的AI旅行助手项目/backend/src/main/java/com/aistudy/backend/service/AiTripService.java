package com.aistudy.backend.service;

import com.aistudy.backend.entity.Trip;

public interface AiTripService {
    void generateMockItinerary(Trip trip);
}