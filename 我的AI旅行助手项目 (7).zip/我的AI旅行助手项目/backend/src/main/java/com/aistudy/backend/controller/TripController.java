package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.*;
import com.aistudy.backend.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/trips")
public class TripController {
    @Autowired
    private TripPoiService tripPoiService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private UserService userService;

    @Autowired
    private TripService tripService;

    @Autowired
    private AiTripService aiTripService;

    // 获取当前登录用户的方法
    private User getCurrentUser() {
        try {
            String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return userService.lambdaQuery().eq(User::getUsername, username).one();
        } catch (Exception e) {
            return null;
        }
    }

    // 1. 根据 ID 查询行程详情
    @GetMapping("/{id}")
    public Result<Trip> getTripById(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip != null) {
            return Result.success(trip);
        }
        return Result.error("行程不存在或已被删除");
    }

    // 2. 创建行程（注意：这里不调 AI 了，光建行程，秒回！）
    @PostMapping("/create")
    public Result<Object> createTrip(@Validated @RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) {
            return Result.error("未登录或登录已过期");
        }

        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false);
        trip.setPoiIds(dto.getPoiIds());

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip); // 只把存好数据库的 trip 返给前端拿 ID
            return Result.success(resultData);
        } else {
            return Result.error("创建行程失败，请稍后重试");
        }
    }

    // 👇 3. 新增：流式生成 AI 接口（前端详情页调这个！）
    @GetMapping(value = "/stream/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamAiText(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) {
            return Flux.just("行程不存在");
        }
        return aiTripService.streamItinerary(trip);
    }

    // 👇 新增：获取行程关联的真实景点列表（按天分组）
    @GetMapping("/{id}/details")
    public Result<java.util.Map<Integer, java.util.List<Poi>>> getTripDetails(@PathVariable Long id) {
        // 1. 查询该行程关联的中间表数据
        java.util.List<TripPoi> tripPois = tripPoiService.lambdaQuery()
                .eq(TripPoi::getTripId, id)
                .orderByAsc(TripPoi::getDayIndex)
                .orderByAsc(TripPoi::getSortOrder)
                .list();

        // 2. 按天分组
        java.util.Map<Integer, java.util.List<Poi>> resultMap = new java.util.LinkedHashMap<>();

        for (TripPoi tp : tripPois) {
            Poi poi = poiService.getById(tp.getPoiId());
            if (poi != null) {
                resultMap.computeIfAbsent(tp.getDayIndex(), k -> new java.util.ArrayList<>()).add(poi);
            }
        }

        return Result.success(resultMap);
    }
    // ================== 以下是最高标准补齐的接口 ==================

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private UserFavoriteService userFavoriteService;

    // 👇 1. 分享行程 (FR-14)
    @PostMapping("/{id}/share")
    public Result<String> shareTrip(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) return Result.error("行程不存在");
        trip.setIsPublic(true);
        tripService.updateById(trip);
        return Result.success("行程已公开分享");
    }

    // 👇 2. 收藏行程 (FR-15 落库 + Redis计数)
    @PostMapping("/{id}/favorite")
    public Result<String> favoriteTrip(@PathVariable Long id) {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");

        // 查库防重
        boolean exists = userFavoriteService.lambdaQuery()
                .eq(UserFavorite::getUserId, user.getId())
                .eq(UserFavorite::getTripId, id)
                .exists();
        if (exists) return Result.error("您已经收藏过该行程啦");

        UserFavorite fav = new UserFavorite();
        fav.setUserId(user.getId());
        fav.setTripId(id);
        userFavoriteService.save(fav);

        // Redis 记录热度
        Long count = stringRedisTemplate.opsForValue().increment("trip:favorite:count:" + id);
        return Result.success("收藏成功！当前热度：" + count);
    }

    // 👇 3. 获取天气 (FR-10)
    @GetMapping("/weather")
    public Result<String> getWeather(@RequestParam String city) {
        // 简单的降级模拟：真实情况你应该调用第三方 API 并存入 Redis (过期时间 1 小时)
        // 为了让你直接跑通，这里返回真实感很强的模拟数据
        String[] weathers = {"今日小雨转阴 18~23°C，已调整<strong>室内景点优先</strong>", "明日转晴 16~26°C，已将长城行程调整至<strong>上午出发</strong>", "空气质量优，已为你加入<strong>景山日落观景</strong>环节"};
        return Result.success(weathers[new java.util.Random().nextInt(weathers.length)]);
    }
}