package com.aistudy.backend.service.impl;
import com.aistudy.backend.mapper.UserFavoriteMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.aistudy.backend.entity.UserFavorite;
import com.aistudy.backend.service.UserFavoriteService;
import org.springframework.stereotype.Service;

@Service
public class UserFavoriteServiceImpl extends ServiceImpl<UserFavoriteMapper, UserFavorite> implements UserFavoriteService {
}