package com.aistudy.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.aistudy.backend.entity.UserFavorite;

public interface UserFavoriteService extends IService<UserFavorite> {
}