package com.aistudy.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.TripPoi;
import com.aistudy.backend.mapper.TripMapper;
import com.aistudy.backend.service.TripPoiService;
import com.aistudy.backend.service.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class TripServiceImpl extends ServiceImpl<TripMapper, Trip> implements TripService {

    @Autowired
    private TripPoiService tripPoiService; // 依赖注入

    @Override
    @Transactional(rollbackFor = Exception.class) // 👈 满分核心考点
    public boolean createTripWithPois(Trip trip) {

        // 1. 保存行程主表
        boolean saveSuccess = this.save(trip);

        // 2. 保存中间表
        List<Long> poiIds = trip.getPoiIds();
        if (poiIds != null && !poiIds.isEmpty()) {
            List<TripPoi> tripPoiList = new ArrayList<>();
            for (int i = 0; i < poiIds.size(); i++) {
                TripPoi tp = new TripPoi();
                tp.setTripId(trip.getId());
                tp.setPoiId(poiIds.get(i));

                // 👇 核心：让第 1 个景点分在 Day 1，第 2 个分在 Day 2，第 3 个分在 Day 3
                tp.setDayIndex(i + 1);
                tp.setSortOrder(1);

                tripPoiList.add(tp);
            }
            tripPoiService.saveBatch(tripPoiList);
        }
        return saveSuccess;
    }
}