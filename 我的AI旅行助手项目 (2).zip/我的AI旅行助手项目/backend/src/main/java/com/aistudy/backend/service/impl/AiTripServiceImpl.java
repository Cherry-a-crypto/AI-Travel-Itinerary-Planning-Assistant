package com.aistudy.backend.service.impl;

import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.TripPoi;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.PoiService;
import com.aistudy.backend.service.TripPoiService; // 👈 新增注入
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AiTripServiceImpl implements AiTripService {

    @Autowired
    private PoiService poiService;

    @Autowired
    private TripPoiService tripPoiService; // 👈 新增注入

    @Value("${ai.api.key}")
    private String apiKey;

    @Value("${ai.api.url}")
    private String apiUrl;

    private final WebClient webClient = WebClient.builder()
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .build();

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Flux<String> streamItinerary(Trip trip) {
        // 1. 核心改变：直接查这个行程已经落库的真实排期！
        List<TripPoi> tripPois = tripPoiService.lambdaQuery()
                .eq(TripPoi::getTripId, trip.getId())
                .orderByAsc(TripPoi::getDayIndex)
                .orderByAsc(TripPoi::getSortOrder)
                .list();

        // 2. 组装给大模型的既定事实
        StringBuilder factContext = new StringBuilder();
        int currentDay = -1;

        for (TripPoi tp : tripPois) {
            Poi poi = poiService.getById(tp.getPoiId());
            if (poi != null) {
                if (tp.getDayIndex() != currentDay) {
                    currentDay = tp.getDayIndex();
                    factContext.append("\n【第").append(currentDay).append("天】：");
                }
                factContext.append(poi.getName()).append("；");
            }
        }

        // 3. 严厉的 Prompt：基于既定事实写文案，严禁乱排
        String prompt = "你是一个专业的旅行规划师。用户要去" + trip.getDestination() + "玩。\n" +
                "以下是系统已经为他排好的绝对固定的行程顺序，请严格按照这个顺序和天数来介绍：\n" +
                factContext.toString() + "\n" +
                "【极其重要】绝对不允许改变景点所在的天数！绝对不允许自己捏造景点！" +
                "请为你看到的每一天，输出丰富的游玩建议、开放时间和注意事项。" +
                "直接输出纯文本，不要使用任何Markdown语法（严禁使用星号**、井号#、表格）。不要有多余的空格。";

        Map<String, Object> requestBody = Map.of(
                "model", "deepseek-chat",
                "messages", List.of(Map.of("role", "user", "content", prompt)),
                "stream", true
        );

        return webClient.post()
                .uri(apiUrl)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToFlux(String.class)
                .doOnNext(data -> System.out.println("原始数据流: " + data))
                .doOnError(e -> System.out.println("❌ 大模型请求报错: " + e.getMessage()));
    }

    @Override
    public Map<String, Object> parseIntent(String userInput) {
        // ... 保持你原来的不变 ...
        String prompt = "你是一个专业的旅行意图解析器。请从用户的输入中提取旅行目的地和天数。" +
                "严格输出 JSON 格式，不要带任何 markdown 标记。格式：{\"city\":\"城市名\",\"days\":数字}。" +
                "用户的输入是：" + userInput;
        Map<String, Object> requestBody = Map.of(
                "model", "deepseek-chat",
                "messages", List.of(Map.of("role", "user", "content", prompt)),
                "response_format", Map.of("type", "json_object")
        );
        try {
            String result = webClient.post().uri(apiUrl)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                    .bodyValue(requestBody)
                    .retrieve().bodyToMono(String.class).block();
            JsonNode root = objectMapper.readTree(result);
            String jsonStr = root.path("choices").get(0).path("message").path("content").asText();
            return objectMapper.readValue(jsonStr, Map.class);
        } catch (Exception e) {
            System.out.println("意图解析失败: " + e.getMessage());
            return Map.of("city", "北京", "days", 3);
        }
    }

    @Override
    public List<Poi> generatePoisByCity(String city) {
        // ... 保持你原来的不变 ...
        String prompt = "你是一个地理数据专家。请列出" + city + "最著名的3个景点。" +
                "必须严格输出 JSON 格式，格式为：{\"pois\": [{\"name\":\"景点名\", \"address\":\"大致地址\", \"lat\":纬度数字, \"lng\":经度数字, \"category\":\"分类\", \"ticket_price\":门票数字}]}。" +
                "请务必保证经纬度准确。";
        Map<String, Object> requestBody = Map.of(
                "model", "deepseek-chat",
                "messages", List.of(Map.of("role", "user", "content", prompt)),
                "response_format", Map.of("type", "json_object")
        );
        try {
            String result = webClient.post().uri(apiUrl)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                    .bodyValue(requestBody)
                    .retrieve().bodyToMono(String.class).block();
            JsonNode root = objectMapper.readTree(result);
            String jsonStr = root.path("choices").get(0).path("message").path("content").asText();
            JsonNode poiArray = objectMapper.readTree(jsonStr).path("pois");
            List<Poi> pois = new java.util.ArrayList<>();
            for (JsonNode node : poiArray) {
                Poi p = new Poi();
                p.setName(node.path("name").asText());
                p.setCity(city);
                p.setAddress(node.path("address").asText());
                p.setLat(node.path("lat").asDouble());
                p.setLng(node.path("lng").asDouble());
                p.setCategory(node.path("category").asText());
                p.setTicketPrice(node.path("ticket_price").asDouble());
                pois.add(p);
            }
            return pois;
        } catch (Exception e) {
            System.out.println("AI 生成景点失败: " + e.getMessage());
            return new java.util.ArrayList<>();
        }
    }
}