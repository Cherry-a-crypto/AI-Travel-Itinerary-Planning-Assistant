package com.aistudy.backend.service;

import com.aistudy.backend.entity.Poi; // 👈 加上这个包
import com.aistudy.backend.entity.Trip;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;

public interface AiTripService {
    Flux<String> streamItinerary(Trip trip);
    Map<String, Object> parseIntent(String userInput);

    // 👇 核心：加上这个方法声明
    List<Poi> generatePoisByCity(String city);
}