package com.aistudy.backend.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.aistudy.backend.entity.UserFavorite;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserFavoriteMapper extends BaseMapper<UserFavorite> {
}