package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.*;
import com.aistudy.backend.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    @Autowired
    private TripPoiService tripPoiService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private UserService userService;

    @Autowired
    private TripService tripService;

    @Autowired
    private AiTripService aiTripService;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private UserFavoriteService userFavoriteService;

    // 获取当前登录用户的方法
    private User getCurrentUser() {
        try {
            String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return userService.lambdaQuery().eq(User::getUsername, username).one();
        } catch (Exception e) {
            return null;
        }
    }

    // 1. 根据 ID 查询行程详情
    @GetMapping("/{id}")
    public Result<Trip> getTripById(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip != null) {
            return Result.success(trip);
        }
        return Result.error("行程不存在或已被删除");
    }

    // 2. 创建行程（普通表单提交）
    @PostMapping("/create")
    public Result<Object> createTrip(@Validated @RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) {
            return Result.error("未登录或登录已过期");
        }

        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false);
        trip.setPoiIds(dto.getPoiIds());

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip);
            return Result.success(resultData);
        } else {
            return Result.error("创建行程失败，请稍后重试");
        }
    }

    // 3. 流式生成 AI 接口（前端详情页调这个）
    @GetMapping(value = "/stream/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamAiText(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) {
            return Flux.just("行程不存在");
        }
        return aiTripService.streamItinerary(trip);
    }

    // 4. 获取行程关联的真实景点列表（按天分组）
    @GetMapping("/{id}/details")
    public Result<Map<Integer, List<Poi>>> getTripDetails(@PathVariable Long id) {
        List<TripPoi> tripPois = tripPoiService.lambdaQuery()
                .eq(TripPoi::getTripId, id)
                .orderByAsc(TripPoi::getDayIndex)
                .orderByAsc(TripPoi::getSortOrder)
                .list();

        Map<Integer, List<Poi>> resultMap = new java.util.LinkedHashMap<>();

        for (TripPoi tp : tripPois) {
            Poi poi = poiService.getById(tp.getPoiId());
            if (poi != null) {
                resultMap.computeIfAbsent(tp.getDayIndex(), k -> new ArrayList<>()).add(poi);
            }
        }
        return Result.success(resultMap);
    }

    // 5. 分享行程 (FR-14)
    @PostMapping("/{id}/share")
    public Result<String> shareTrip(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) return Result.error("行程不存在");
        trip.setIsPublic(true);
        tripService.updateById(trip);
        return Result.success("行程已公开分享");
    }

    // 6. 收藏行程 (FR-15 落库 + Redis计数)
    @PostMapping("/{id}/favorite")
    public Result<String> favoriteTrip(@PathVariable Long id) {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");

        boolean exists = userFavoriteService.lambdaQuery()
                .eq(UserFavorite::getUserId, user.getId())
                .eq(UserFavorite::getTripId, id)
                .exists();
        if (exists) return Result.error("您已经收藏过该行程啦");

        UserFavorite fav = new UserFavorite();
        fav.setUserId(user.getId());
        fav.setTripId(id);
        userFavoriteService.save(fav);

        Long count = stringRedisTemplate.opsForValue().increment("trip:favorite:count:" + id);
        return Result.success("收藏成功！当前热度：" + count);
    }

    // 7. 获取天气 (FR-10)
    @GetMapping("/weather")
    public Result<String> getWeather(@RequestParam String city) {
        String[] weathers = {"今日小雨转阴 18~23°C，已调整<strong>室内景点优先</strong>", "明日转晴 16~26°C，已将长城行程调整至<strong>上午出发</strong>", "空气质量优，已为你加入<strong>景山日落观景</strong>环节"};
        return Result.success(weathers[new java.util.Random().nextInt(weathers.length)]);
    }

    // 8. 自然语言意图解析并生成行程 (核心功能)
    @PostMapping("/generate-by-intent")
    public Result<Object> generateByIntent(@RequestBody Map<String, String> requestBody) {
        String userIntent = requestBody.get("intent");
        if (userIntent == null || userIntent.isEmpty()) {
            return Result.error("请输入旅行需求");
        }

        // 1. 调用大模型解析意图
        Map<String, Object> intentData = aiTripService.parseIntent(userIntent);
        String destination = (String) intentData.getOrDefault("city", "北京");
        Integer days = (Integer) intentData.getOrDefault("days", 3);

        User currentUser = getCurrentUser();
        if (currentUser == null) return Result.error("未登录");

        // 2. 动态查库：看数据库里有没有该城市的景点
        List<Poi> cityPois = poiService.lambdaQuery()
                .eq(Poi::getCity, destination)
                .last("LIMIT 3")
                .list();

        List<Long> finalPoiIds = new ArrayList<>();

        if (!cityPois.isEmpty()) {
            // 情况 A：数据库里有，直接绑定
            for (Poi p : cityPois) {
                finalPoiIds.add(p.getId());
            }
        } else {
            // 情况 B：数据库里没有，让 AI 现场生成并自动入库！
            System.out.println("【智能扩充】数据库无此城市，AI 正在生成...");
            List<Poi> aiPois = aiTripService.generatePoisByCity(destination);

            if (!aiPois.isEmpty()) {
                poiService.saveBatch(aiPois); // 将 AI 生成的景点存入数据库
                for (Poi p : aiPois) {
                    finalPoiIds.add(p.getId()); // 拿到刚插入的 ID
                }
            } else {
                // 情况 C：极端兜底（AI 也挂了）：拿数据库前三个随便顶一下
                List<Poi> allPois = poiService.lambdaQuery().last("LIMIT 3").list();
                for (Poi p : allPois) {
                    finalPoiIds.add(p.getId());
                }
            }
        }

        // 3. 组装行程
        Trip trip = new Trip();
        trip.setTitle(destination + " " + days + "日游");
        trip.setDestination(destination);
        trip.setUserId(currentUser.getId());
        trip.setBudget(new java.math.BigDecimal("3000"));
        trip.setIsPublic(false);

        // 把动态查出来的或者 AI 刚生成的 ID 塞进去
        trip.setPoiIds(finalPoiIds);

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip);
            return Result.success(resultData);
        }
        return Result.error("生成行程失败");
    }

    // 9. 接收前端拖拽后的新顺序并重排
    @PutMapping("/{id}/items")
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public Result<String> reorderTripItems(
            @PathVariable Long id,
            @RequestBody java.util.Map<String, java.util.List<Long>> details) {

        // 1. 先彻底清空该行程下的所有景点关联
        tripPoiService.lambdaUpdate().eq(TripPoi::getTripId, id).remove();

        // 2. 按照前端传来的最新分组，重新插入
        if (details != null && !details.isEmpty()) {
            java.util.List<TripPoi> newList = new java.util.ArrayList<>();

            // 遍历每一天（比如 key 是 "1", "2", "3"）
            details.forEach((dayStr, poiIds) -> {
                if (poiIds != null && !poiIds.isEmpty()) {
                    Integer dayIndex = Integer.parseInt(dayStr);
                    for (int i = 0; i < poiIds.size(); i++) {
                        TripPoi tp = new TripPoi();
                        tp.setTripId(id);
                        tp.setPoiId(poiIds.get(i));
                        tp.setSortOrder(i + 1); // 对应的排序值
                        tp.setDayIndex(dayIndex); // 对应的天数
                        newList.add(tp);
                    }
                }
            });
            tripPoiService.saveBatch(newList);
        }
        return Result.success("跨天路线重排成功");
    }

    // 10. 发现页：获取所有公开的行程 (FR-14)
    @GetMapping("/discover")
    public Result<List<Trip>> discoverTrips() {
        List<Trip> publicTrips = tripService.lambdaQuery()
                .eq(Trip::getIsPublic, true)
                .orderByDesc(Trip::getId)
                .list();
        return Result.success(publicTrips);
    }

    // 11. 我的页：获取当前用户创建的行程
    @GetMapping("/my-trips")
    public Result<List<Trip>> getMyTrips() {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");
        List<Trip> myTrips = tripService.lambdaQuery()
                .eq(Trip::getUserId, user.getId())
                .orderByDesc(Trip::getId)
                .list();
        return Result.success(myTrips);
    }

    // 12. 我的页：获取当前用户收藏的行程 (修复了 SQL 报错)
    // 12. 我的页：获取当前用户收藏的行程 (终极无敌稳定版)
    // 12. 我的页：获取当前用户收藏的行程
    // 12. 我的页：获取当前用户收藏的行程
    @GetMapping("/my-favorites")
    public Result<List<Trip>> getMyFavorites() {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");

        // 1. 查出用户所有收藏记录
        List<UserFavorite> favorites = userFavoriteService.lambdaQuery()
                .eq(UserFavorite::getUserId, user.getId())
                .list();

        if (favorites == null || favorites.isEmpty()) {
            return Result.success(new ArrayList<>());
        }

        // 2. 提取非空的 tripId
        List<Long> tripIds = new ArrayList<>();
        for (UserFavorite fav : favorites) {
            if (fav.getTripId() != null) {
                tripIds.add(fav.getTripId());
            }
        }

        if (tripIds.isEmpty()) {
            return Result.success(new ArrayList<>());
        }

        // 3. 核心：使用 lambdaQuery 替换 listByIds，彻底告别 SQL 报错
        List<Trip> favoriteTrips = tripService.lambdaQuery()
                .in(Trip::getId, tripIds)
                .list();

        return Result.success(favoriteTrips);
    }
}