package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/users")
public class UserController{
    @Autowired
    private UserService userService;
    @GetMapping("/list")
    public Result <List<User>> list(){
        List<User>list=userService.list();
        return Result.success(list);
    }
    @PostMapping("/add")
    public Result<Boolean>addUser(@Valid @RequestBody User user){
        boolean success=userService.save(user);
            return Result.success(success);

    }
    @PutMapping("/update")
    public Result<Boolean>updateUser(@Valid @RequestBody User user){
        boolean success=userService.updateById(user);
        return Result.success(success);
    }
    @DeleteMapping ("/delete/{id}")
    public Result<Boolean>deletUser(@PathVariable Long id){
        boolean success=userService.removeById(id);
        return Result.success(success);
    }

}
