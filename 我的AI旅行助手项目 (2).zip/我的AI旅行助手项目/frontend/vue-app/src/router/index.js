import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'login',
      component: LoginView
    },
    {
      path: '/home',
      name: 'home',
      component: () => import('../views/HomeView.vue')
    },
    {
      path: '/detail',
      name: 'detail',
      component: () => import('../views/DetailView.vue')
    },
    {
      path: '/register',
      name: 'register',
      component: () => import('../views/RegisterView.vue')
    },
    {
      path: '/poi-list',
      name: 'poiList',
      component: () => import('../views/PoiListView.vue')
    },
    // 👇 注意：这两个我换成了懒加载写法，和上面保持统一，并且不需要在上面 import 了
    {
      path: '/discover',
      name: 'discover',
      component: () => import('../views/DiscoverView.vue')
    },
    {
      path: '/mine',
      name: 'mine',
      component: () => import('../views/MineView.vue')
    }
  ]
})

// 路由守卫：拦截未登录的访问
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  
  // 如果要去首页或详情页，但没有 Token，就强制踢回登录页
  if (to.path !== '/' && to.path !== '/register' && !token)  {
    next('/')
  } else {
    next()
  }
})

export default router