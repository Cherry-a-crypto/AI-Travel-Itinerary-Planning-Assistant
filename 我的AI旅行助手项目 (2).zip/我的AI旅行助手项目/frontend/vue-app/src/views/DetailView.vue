<script setup>
import { marked } from 'marked'
import { ref, onMounted, nextTick } from 'vue' // 👈 引入 nextTick
import { useRouter, useRoute } from 'vue-router'
import request from '../utils/request'
import { useUserStore } from '../stores/user'
import { ElMessage } from 'element-plus'
import draggable from 'vuedraggable'

const userStore = useUserStore()
const router = useRouter()
const route = useRoute()

const activeDays = ref([1])
const toggleDay = (day) => {
  if (activeDays.value.includes(day)) {
    activeDays.value = activeDays.value.filter(d => d !== day)
  } else {
    activeDays.value.push(day)
  }
}

const weatherTip = ref('正在获取实时天气...')
const aiText = ref('')
const trip = ref({ title: '加载中...', destination: '', startDate: '', endDate: '' })
const tripDetails = ref({}) 
let mapInstance = null
const aiScrollBox = ref(null) // 👈 新增：AI 文本框的 ref

// 👇 画地图的逻辑
const renderDynamicMap = (details) => {
  if (!window.AMap) return
  if (mapInstance) {
    mapInstance.destroy() // 先销毁旧地图
  }
  
  mapInstance = new window.AMap.Map('amap-container', {
    zoom: 11,
    center: [116.397, 39.916]
  });

  const path = [];
  const sortedDays = Object.keys(details).sort((a, b) => a - b);
  sortedDays.forEach(day => {
    details[day].forEach(poi => {
      if (poi.lat && poi.lng) {
        const position = [Number(poi.lng), Number(poi.lat)];
        path.push(position);
        
        new window.AMap.Marker({
          position: position,
          title: poi.name,
          label: { content: poi.name, direction: 'top' }
        }).setMap(mapInstance);
      }
    });
  });

  if (path.length > 1) {
    new window.AMap.Polyline({
      path: path,
      strokeColor: '#0284c7',
      strokeWeight: 5,
      strokeStyle: 'dashed',
      showDir: true
    }).setMap(mapInstance);
    mapInstance.setFitView();
  }
}

// 👇 核心抽离：独立的 AI 流式请求函数
const fetchAiStream = (tripId) => {
  aiText.value = '🤖 AI 正在大脑飞速运转中...'
  const token = userStore.token 
  
  fetch(`http://localhost:8080/api/trips/stream/${tripId}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(response => {
    if (!response.ok) throw new Error('网络请求失败')
    const reader = response.body.getReader()
    const decoder = new TextDecoder('utf-8')
    
    let rawText = ''
    let buffer = '' 

    const readStream = () => {
      reader.read().then(({ done, value }) => {
        if (done) {
          aiText.value = marked.parse(rawText)
          return
        }

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() 

        for (const line of lines) {
          const trimmedLine = line.trim()
          if (!trimmedLine) continue

          if (trimmedLine.startsWith('data:')) {
            let content = trimmedLine.substring(5).trim()
            if (content === '[DONE]') continue

            try {
              const parsed = JSON.parse(content)
              if (parsed.content) rawText += parsed.content
              else if (parsed.choices && parsed.choices[0].delta.content) rawText += parsed.choices[0].delta.content
              else if (typeof parsed === 'string') rawText += parsed
            } catch (e) {
              rawText += content + '\n' 
            }
          } else {
            rawText += trimmedLine + '\n'
          }
        }

        aiText.value = marked.parse(rawText)
        
        // 👇 每次更新文字后，自动滚动到底部
        nextTick(() => {
          if (aiScrollBox.value) {
            aiScrollBox.value.scrollTop = aiScrollBox.value.scrollHeight
          }
        })

        readStream() 
      })
    }
    readStream()
  }).catch(err => {
    console.error("AI流式请求失败", err)
    aiText.value = "AI服务开小差了，请稍后再试。"
  })
}

// 👇 拖拽结束逻辑
const onDragEnd = async () => {
  try {
    tripDetails.value = JSON.parse(JSON.stringify(tripDetails.value))
    renderDynamicMap(tripDetails.value)

    const payload = {}
    for (const day in tripDetails.value) {
      payload[day] = tripDetails.value[day].map(p => p.id)
    }

    const res = await request.put(`/api/trips/${route.query.id}/items`, payload)
    if (res.code === 200) {
      ElMessage.success('行程已更新，AI 正在为您重新生成专属建议...')
      
      // 👇 核心：保存成功后，重新调用 AI 流式请求！
      fetchAiStream(route.query.id)
    }
  } catch (error) {
    ElMessage.error('重排失败')
  }
}

const handleShare = async () => {
  try {
    const res = await request.post(`/api/trips/${route.query.id}/share`)
    if (res.code === 200) ElMessage.success(res.message)
    else ElMessage.warning(res.message)
  } catch (error) {
    ElMessage.error('分享失败')
  }
}

const handleFavorite = async () => {
  try {
    const res = await request.post(`/api/trips/${route.query.id}/favorite`)
    if (res.code === 200) ElMessage.success(res.message)
    else ElMessage.warning(res.message)
  } catch (error) {
    ElMessage.error('收藏失败')
  }
}

onMounted(async () => {
  const tripId = route.query.id
  if (!tripId) return

  try {
    const res = await request.get(`/api/trips/${tripId}`)
    if (res.code === 200) {
      trip.value = res.data
      const weatherRes = await request.get(`/api/trips/weather?city=${trip.value.destination}`)
      if (weatherRes.code === 200) weatherTip.value = weatherRes.data
    }
    
    const detailsRes = await request.get(`/api/trips/${tripId}/details`)
    if (detailsRes.code === 200) {
      tripDetails.value = detailsRes.data
      renderDynamicMap(detailsRes.data)
    }
  } catch (error) {
    console.error('获取行程失败', error)
  }

  // 👇 页面加载时，调用抽离出来的流式方法
  fetchAiStream(tripId)
})
</script>

<template>
  <div class="min-h-screen bg-sky-50/70">
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <button @click="router.push('/home')" class="flex items-center gap-1.5 text-sky-600 hover:text-sky-500 font-medium transition">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
          返回首页
        </button>
        <span class="font-bold text-slate-700">行程详情</span>
      </div>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-8 flex flex-col lg:flex-row gap-6 items-stretch">
      
      <section class="lg:w-3/5 relative rounded-2xl overflow-hidden border border-slate-200 shadow-md min-h-[70vh]">
        <div id="amap-container" class="w-full h-full absolute inset-0"></div>
      </section>

      <section class="lg:w-2/5 bg-white rounded-2xl shadow-md border border-sky-100 p-6 flex flex-col max-h-[85vh]">
        <div class="flex items-start justify-between">
          <div>
            <h2 class="text-2xl font-bold text-slate-800">{{ trip.title }} <span class="bg-gradient-to-r from-sky-500 to-blue-500 bg-clip-text text-transparent text-lg">（AI定制）</span></h2>
            <p class="text-xs text-slate-400 mt-1">
              {{ trip.startDate ? trip.startDate.substring(0, 10) : '' }} 至 
              {{ trip.endDate ? trip.endDate.substring(0, 10) : '' }} · 2人出行
            </p>
          </div>
          <span class="shrink-0 px-2.5 py-1 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold">AI 已优化</span>
        </div>

        <div class="mt-4 flex items-center gap-2.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 text-sky-700 text-sm rounded-xl px-4 py-3 shrink-0">
          <span class="text-lg">🌦️</span>
          <span v-html="weatherTip"></span>
        </div>
        
        <!-- 👇 核心修改：加上 ref="aiScrollBox" 和 scroll-smooth -->
        <div ref="aiScrollBox" class="mt-4 bg-sky-50 rounded-2xl p-5 border border-sky-100 flex-1 min-h-[250px] overflow-y-auto scroll-smooth">
          <div class="flex items-center gap-2 mb-3">
            <span class="text-xl">🤖</span>
            <h3 class="font-bold text-sky-700">AI 专属行程规划建议</h3>
          </div>
          <div class="text-sm text-slate-600 leading-relaxed break-words overflow-x-auto markdown-body" v-html="aiText || '🤖 AI 正在大脑飞速运转中...'"></div>
        </div>

        <div class="mt-5 space-y-3 shrink-0 max-h-[35vh] overflow-y-auto">
          <div v-for="(pois, dayIndex) in tripDetails" :key="dayIndex" class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
            <button @click="toggleDay(dayIndex)" class="w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r from-sky-500 to-blue-500 text-white">
              <span class="font-semibold flex items-center gap-2">Day {{ dayIndex }} · 专属路线 <span class="text-xs bg-white/20 px-2 py-0.5 rounded-full">{{ pois.length }} 个地点</span></span>
              <span class="acc-arrow" :class="{'rotate-180': activeDays.includes(dayIndex)}">▾</span>
            </button>
            
            <div class="acc-body" :style="{ maxHeight: activeDays.includes(dayIndex) ? '600px' : '0px' }">
              <draggable 
                v-model="tripDetails[dayIndex]" 
                item-key="id" 
                :group="{ name: 'pois' }" 
                @end="onDragEnd"
                class="divide-y divide-sky-50 cursor-move min-h-[50px]"
              >
                <template #item="{ element: poi }">
                  <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50 transition">
                    <span class="text-slate-300 font-bold text-lg">≡</span>
                    <span class="text-sky-600 font-mono font-bold w-14">09:00</span>
                    <div class="flex-1">
                      <p class="font-medium text-slate-800">{{ poi.name }}</p>
                      <p class="text-xs text-slate-400 line-clamp-1">{{ poi.description || '建议游览 2 小时' }}</p>
                    </div>
                    <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥{{ poi.ticketPrice || '免费' }}</span>
                  </li>
                </template>
              </draggable>
            </div>
          </div>
          
          <div v-if="Object.keys(tripDetails).length === 0" class="text-center py-6 bg-sky-50/50 rounded-xl border border-sky-100">
            <p class="text-sm text-slate-400">暂无详细景点安排，请查看右侧 AI 建议。</p>
          </div>
        </div>

        <div class="mt-6 flex gap-2 shrink-0">
          <button @click="handleShare" class="flex-1 py-3 rounded-xl border border-green-500 text-green-600 font-semibold hover:bg-green-50">🔗 分享</button>
          <button @click="handleFavorite" class="flex-1 py-3 rounded-xl border border-amber-400 text-amber-500 font-semibold hover:bg-amber-50">⭐ 收藏</button>
          <button @click="alert('已为你打开导航')" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-500 text-white font-semibold">🧭 导航</button>
        </div>
      </section>
    </main>
  </div>
</template>

<style scoped>
.markdown-body { word-break: break-word; font-size: 0.875rem; color: #475569; }
.markdown-body p { margin-bottom: 0.75rem; line-height: 1.7; }
.markdown-body strong { font-weight: 700; color: #0284c7; }
.markdown-body h1, .markdown-body h2, .markdown-body h3 { font-size: 1rem; font-weight: bold; margin-top: 1rem; margin-bottom: 0.5rem; color: #0f172a; }
.markdown-body ul, .markdown-body ol { list-style-type: decimal; padding-left: 1.25rem; margin-bottom: 0.75rem; }
.markdown-body ul { list-style-type: disc; }
.markdown-body li { margin-bottom: 0.25rem; }
</style>