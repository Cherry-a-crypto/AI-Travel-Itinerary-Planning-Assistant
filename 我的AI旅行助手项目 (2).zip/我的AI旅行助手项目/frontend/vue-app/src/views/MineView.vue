<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()

const activeTab = ref('my')
const myTrips = ref([])
const favTrips = ref([])

onMounted(async () => {
  try {
    const myRes = await request.get('/api/trips/my-trips')
    if (myRes.code === 200) myTrips.value = myRes.data

    const favRes = await request.get('/api/trips/my-favorites')
    if (favRes.code === 200) favTrips.value = favRes.data
  } catch (error) {
    console.error('获取个人数据失败', error)
  }
})

const logout = () => {
  userStore.logout()
  router.push('/')
}
</script>

<template>
  <div class="min-h-screen bg-sky-50/50">
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold text-sky-600">个人中心</span>
        </div>
        <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <span @click="router.push('/home')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">首页</span>
          <span @click="router.push('/discover')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">发现</span>
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">我的</a>
        </div>
        <button @click="logout" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white transition">退出登录</button>
      </div>
    </nav>

    <main class="max-w-6xl mx-auto px-6 py-10">
      <!-- 用户信息卡片 -->
      <div class="bg-white rounded-2xl shadow-md p-8 mb-8 flex items-center gap-6">
        <div class="w-20 h-20 bg-gradient-to-r from-sky-400 to-blue-500 rounded-full flex items-center justify-center text-3xl text-white font-bold">
          {{ userStore.userInfo?.nickname?.[0] || 'U' }}
        </div>
        <div>
          <h2 class="text-2xl font-bold text-slate-800">{{ userStore.userInfo?.nickname || '旅行者' }}</h2>
          <p class="text-sm text-slate-400 mt-1">账号：{{ userStore.userInfo?.username }}</p>
        </div>
      </div>

      <!-- Tab 切换 -->
      <div class="flex gap-4 mb-6">
        <button @click="activeTab = 'my'" :class="activeTab === 'my' ? 'bg-sky-500 text-white' : 'bg-white text-slate-600'" class="px-6 py-2 rounded-xl font-semibold shadow-sm transition">我创建的行程 ({{ myTrips.length }})</button>
        <button @click="activeTab = 'fav'" :class="activeTab === 'fav' ? 'bg-sky-500 text-white' : 'bg-white text-slate-600'" class="px-6 py-2 rounded-xl font-semibold shadow-sm transition">我收藏的行程 ({{ favTrips.length }})</button>
      </div>

      <!-- 行程列表 -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="t in (activeTab === 'my' ? myTrips : favTrips)" :key="t.id" class="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition cursor-pointer border border-sky-50" @click="router.push(`/detail?id=${t.id}`)">
          <h3 class="text-xl font-bold text-slate-800 mb-2">{{ t.title }}</h3>
          <p class="text-sm text-slate-500">📍 {{ t.destination }} · 💰 ¥{{ t.budget }}</p>
          <div class="mt-4 text-xs text-sky-600 font-semibold text-right">查看详情 →</div>
        </div>
      </div>
      <div v-if="(activeTab === 'my' ? myTrips : favTrips).length === 0" class="text-center text-slate-400 py-10 bg-white rounded-2xl">
        这里空空如也~
      </div>
    </main>
  </div>
</template>