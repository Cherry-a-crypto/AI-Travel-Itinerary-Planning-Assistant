<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()
const trips = ref([])
const isLoading = ref(true)

onMounted(async () => {
  try {
    const res = await request.get('/api/trips/discover')
    if (res.code === 200) trips.value = res.data
  } catch (error) {
    ElMessage.error('获取发现列表失败')
  } finally {
    isLoading.value = false
  }
})
</script>

<template>
  <div class="min-h-screen bg-sky-50/50">
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold text-sky-600">发现社区</span>
        </div>
        <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <span @click="router.push('/home')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">首页</span>
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">发现</a>
          <span @click="router.push('/mine')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">我的</span>
        </div>
        <button @click="router.push('/')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white transition">退出</button>
      </div>
    </nav>

    <main class="max-w-6xl mx-auto px-6 py-10">
      <h1 class="text-3xl font-extrabold text-slate-800 mb-8 flex items-center gap-2">🌍 大家都在去哪玩？</h1>
      
      <div v-if="isLoading" class="text-center text-sky-500 py-20">正在加载社区行程...</div>
      
      <div v-else-if="trips.length === 0" class="text-center text-slate-400 py-20 bg-white rounded-2xl shadow-sm">
        暂无公开的行程，快去生成一个并点击“分享”吧！
      </div>

      <div v-else class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="t in trips" :key="t.id" class="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl hover:-translate-y-1 transition cursor-pointer border border-sky-50" @click="router.push(`/detail?id=${t.id}`)">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-xl font-bold text-slate-800">{{ t.title }}</h3>
            <span class="text-xs bg-sky-100 text-sky-600 px-2 py-1 rounded-md">公开</span>
          </div>
          <p class="text-sm text-slate-500 mb-2">📍 目的地：{{ t.destination }}</p>
          <p class="text-sm text-slate-500 mb-4">📅 时间：{{ t.startDate?.substring(0,10) }} 至 {{ t.endDate?.substring(0,10) }}</p>
          <div class="text-xs text-slate-400 mt-4 border-t pt-3 flex justify-between">
            <span>点击查看行程详情</span>
            <span>💰 ¥{{ t.budget }}</span>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>