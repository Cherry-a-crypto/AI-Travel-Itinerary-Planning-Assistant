package com.aistudy.backend.service.impl;

import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.PoiService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;

@Service
public class AiTripServiceImpl implements AiTripService {

    @Autowired
    private PoiService poiService;

    @Value("${ai.api.key}")
    private String apiKey;

    @Value("${ai.api.url}")
    private String apiUrl;

    private final WebClient webClient = WebClient.builder()
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .build();

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Flux<String> streamItinerary(Trip trip) {
        List<Poi> pois = poiService.list();
        // 👇 1. 调用贪心算法给景点排好序
        List<Poi> optimizedPois = com.aistudy.backend.utils.TspSolver.optimizeRoute(pois);
        // 👇 2. 把排好序的列表转成字符串
        String poiStr = optimizedPois.isEmpty() ? "随便安排" : optimizedPois.toString();

        String prompt = "你是一个专业的旅行规划师。用户要去" + trip.getDestination() +
                "玩。请从以下景点列表中挑选3个，规划每天的行程。景点列表：" + poiStr;

        Map<String, Object> requestBody = Map.of(
                "model", "deepseek-chat",
                "messages", List.of(Map.of("role", "user", "content", prompt)),
                "stream", true
        );

        return webClient.post()
                .uri(apiUrl)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToFlux(String.class)
                // 👇 这里直接解析，不再用死板的 filter
                .map(data -> {
                    try {
                        String json = data.trim();
                        // 兼容可能带 data: 前缀的情况
                        if (json.startsWith("data:")) {
                            json = json.substring(5).trim();
                        }
                        if (json.isEmpty() || json.equals("[DONE]") || !json.startsWith("{")) {
                            return "";
                        }
                        JsonNode root = objectMapper.readTree(json);
                        JsonNode contentNode = root.path("choices").path(0).path("delta").path("content");
                        if (contentNode.isMissingNode() || contentNode.isNull()) {
                            return "";
                        }
                        return contentNode.asText();
                    } catch (Exception e) {
                        return "";
                    }
                })
                .filter(text -> !text.isEmpty()) // 过滤空字符
                .doOnError(e -> System.out.println("❌ 大模型请求报错: " + e.getMessage())); // 加上错误监控
    }
}