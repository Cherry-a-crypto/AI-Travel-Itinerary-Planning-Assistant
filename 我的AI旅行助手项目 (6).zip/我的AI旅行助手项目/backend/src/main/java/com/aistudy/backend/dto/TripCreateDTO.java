package com.aistudy.backend.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class TripCreateDTO {

    @NotBlank(message = "行程标题不能为空") // 👈 加了这个
    private String title;

    @NotBlank(message = "目的地不能为空")   // 👈 加了这个
    private String destination;

    private Date startDate;
    private Date endDate;

    @NotNull(message = "预算不能为空")      // 👈 加了这个
    private BigDecimal budget;

    private List<Long> poiIds;

    // 注意：这里没有 id，没有 userId，没有 isPublic！
    // 这些敏感字段由后端自己控制，前端无权干涉！
}