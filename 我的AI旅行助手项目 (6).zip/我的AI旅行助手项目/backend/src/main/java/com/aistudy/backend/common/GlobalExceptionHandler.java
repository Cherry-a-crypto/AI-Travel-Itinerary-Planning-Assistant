package com.aistudy.backend.common;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // 拦截系统里的所有异常
    @ExceptionHandler(Exception.class)
    public Result<String> handleException(Exception e) {
        // 实际开发中这里会打日志，现在为了演示，直接把错误信息返回
        return Result.error("系统异常：" + e.getMessage());
    }
    // 👇 专门拦截 @Validated 参数校验失败的异常（新增的）
    @org.springframework.web.bind.annotation.ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
    public Result<String> handleValidationExceptions(org.springframework.web.bind.MethodArgumentNotValidException ex) {
        // 提取第一条校验失败的报错信息
        org.springframework.validation.FieldError fieldError = ex.getBindingResult().getFieldError();
        String errorMsg = fieldError != null ? fieldError.getDefaultMessage() : "参数校验失败";

        // 直接返回 400 的提示
        return Result.error(errorMsg);
    }
}