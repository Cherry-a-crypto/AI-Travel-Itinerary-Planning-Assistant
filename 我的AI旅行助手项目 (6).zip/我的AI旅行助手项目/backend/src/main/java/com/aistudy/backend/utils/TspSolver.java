package com.aistudy.backend.utils;

import com.aistudy.backend.entity.Poi;
import java.util.ArrayList;
import java.util.List;

public class TspSolver {

    public static List<Poi> optimizeRoute(List<Poi> pois) {
        if (pois == null || pois.size() <= 1) return pois;

        List<Poi> optimized = new ArrayList<>();
        List<Poi> unvisited = new ArrayList<>(pois);

        Poi current = unvisited.remove(0);
        optimized.add(current);

        while (!unvisited.isEmpty()) {
            Poi nearest = null;
            double minDistance = Double.MAX_VALUE;

            for (Poi candidate : unvisited) {
                // 防止空指针：如果没有经纬度，直接跳过距离计算
                if (current.getLat() == null || current.getLng() == null ||
                        candidate.getLat() == null || candidate.getLng() == null) {
                    continue;
                }

                // 👇 换成 getLat() 和 getLng()
                double dist = GeoUtils.calculateDistance(
                        current.getLat(), current.getLng(),
                        candidate.getLat(), candidate.getLng()
                );

                if (dist < minDistance) {
                    minDistance = dist;
                    nearest = candidate;
                }
            }

            if (nearest == null) {
                nearest = unvisited.get(0);
            }

            optimized.add(nearest);
            unvisited.remove(nearest);
            current = nearest;
        }
        System.out.println("【算法层】贪心策略优化前的景点: " + pois.stream().map(Poi::getName).toList());
        System.out.println("【算法层】贪心策略优化后的路线: " + optimized.stream().map(Poi::getName).toList());
        return optimized;
    }
}