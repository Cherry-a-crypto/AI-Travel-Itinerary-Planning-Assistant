package com.aistudy.backend.service;

import com.aistudy.backend.entity.Trip;
import reactor.core.publisher.Flux; // 👈 必须要有这个包

public interface AiTripService {
    // 👈 返回类型必须是 Flux，代表数据流
    Flux<String> streamItinerary(Trip trip);

}