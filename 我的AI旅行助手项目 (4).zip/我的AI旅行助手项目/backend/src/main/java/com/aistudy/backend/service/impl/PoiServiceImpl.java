package com.aistudy.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.mapper.PoiMapper;
import com.aistudy.backend.service.PoiService;
import org.springframework.stereotype.Service;

@Service
public class PoiServiceImpl extends ServiceImpl<PoiMapper, Poi> implements PoiService {
}