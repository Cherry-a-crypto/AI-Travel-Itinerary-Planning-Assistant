package com.aistudy.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.aistudy.backend.entity.TripPoi;
import com.aistudy.backend.mapper.TripPoiMapper;
import com.aistudy.backend.service.TripPoiService;
import org.springframework.stereotype.Service;

@Service
public class TripPoiServiceImpl extends ServiceImpl<TripPoiMapper, TripPoi> implements TripPoiService {
}