package com.aistudy.backend.common;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // 拦截系统里的所有异常
    @ExceptionHandler(Exception.class)
    public Result<String> handleException(Exception e) {
        // 实际开发中这里会打日志，现在为了演示，直接把错误信息返回
        return Result.error("系统异常：" + e.getMessage());
    }
}