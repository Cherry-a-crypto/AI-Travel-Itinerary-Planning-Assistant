package com.aistudy.backend.service.impl;

import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.PoiService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class AiTripServiceImpl implements AiTripService {

    @Autowired
    private PoiService poiService;

    // 👇 👇 👇 把这里替换成你真实的 DeepSeek API Key 👇 👇 👇
    private static final String API_KEY = "sk-4f3ba430a81b45abbeb7e696099b4e6d";
    private static final String API_URL = "https://api.deepseek.com/chat/completions";

    @Override
    public String generateMockItinerary(Trip trip) {
        try {
            return callDeepSeekAI(trip);
        } catch (Exception e) {
            System.err.println("AI调用失败，触发降级策略！原因: " + e.getMessage());
            return "AI服务繁忙，已为你生成默认行程。";
        }
    }

    private String callDeepSeekAI(Trip trip) throws Exception {
        List<Poi> pois = poiService.list();
        if (pois.isEmpty()) return "没有可用的景点数据。";

        // 1. 组装提示词
        String prompt = "你是一个专业的旅行规划师。用户要去" + trip.getDestination() + "玩。请从以下景点列表中挑选3个，简单规划一下每天的行程。景点列表：" + pois.toString();

        // 2. 构建 JSON 请求体 (使用 Map 避免字符串拼写错误)
        Map<String, Object> message = new HashMap<>();
        message.put("role", "user");
        message.put("content", prompt);

        Map<String, Object> requestBodyMap = new HashMap<>();
        requestBodyMap.put("model", "deepseek-chat");
        requestBodyMap.put("messages", new Object[]{message});

        ObjectMapper mapper = new ObjectMapper();
        String jsonBody = mapper.writeValueAsString(requestBodyMap);

        // 3. 发送 HTTP 请求
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(jsonBody, MediaType.parse("application/json")))
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new RuntimeException("API请求失败: " + response.code());
            String responseBody = response.body().string();

            // 4. 解析 AI 的回复
            JsonNode root = mapper.readTree(responseBody);
            String content = root.path("choices").get(0).path("message").path("content").asText();

            System.out.println("============== AI 真实返回内容 ==============");
            System.out.println(content);
            System.out.println("=============================================");

            return content;
        }
    }
}