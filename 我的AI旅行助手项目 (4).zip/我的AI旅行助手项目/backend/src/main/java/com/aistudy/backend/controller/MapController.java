package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.util.*;

@RestController
@RequestMapping("/api/map")
public class MapController {

    // ⚠️ 替换成你在高德申请的 Web服务 Key
    private static final String AMAP_KEY = "88f1f165d50a4fa7ba05670cf4f7eb7c";

    @GetMapping("/nearby")
    public Result<List<Map<String, Object>>> getNearby(
            @RequestParam String lng,
            @RequestParam String lat,
            @RequestParam String keyword) {

        // 高德周边搜索 API 地址
        String url = String.format(
                "https://restapi.amap.com/v3/place/around?key=%s&location=%s,%s&keywords=%s&radius=2000&offset=10",
                AMAP_KEY, lng, lat, keyword
        );

        RestTemplate restTemplate = new RestTemplate();
        try {
            // 发送 HTTP GET 请求，拿到高德返回的 JSON
            Map<String, Object> response = restTemplate.getForObject(url, Map.class);

            // 判断高德返回是否成功 (status = 1 代表成功)
            if (response != null && "1".equals(response.get("status"))) {
                List<Map<String, Object>> pois = (List<Map<String, Object>>) response.get("pois");
                List<Map<String, Object>> resultList = new ArrayList<>();

                // 把高德的数据精简一下，传给前端
                if (pois != null) {
                    for (Map<String, Object> poi : pois) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("name", poi.get("name"));
                        item.put("address", poi.get("address"));
                        // 高德返回的 location 是 "经度,纬度" 的字符串，需要拆开
                        String location = (String) poi.get("location");
                        item.put("lng", location.split(",")[0]);
                        item.put("lat", location.split(",")[1]);

                        resultList.add(item);
                    }
                }
                return Result.success(resultList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Result.error("获取周边数据失败");
    }
}