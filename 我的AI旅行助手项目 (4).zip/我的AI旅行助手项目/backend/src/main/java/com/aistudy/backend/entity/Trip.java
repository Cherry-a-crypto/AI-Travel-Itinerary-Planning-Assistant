package com.aistudy.backend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@TableName("trip")
public class Trip {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private String title;
    private String destination;
    private Date startDate;
    private Date endDate;
    private BigDecimal budget;
    private Boolean isPublic;
    // 👇 加上这一行
    private String postContent;
    @TableField(exist = false)
    private List<Long> poiIds;
}