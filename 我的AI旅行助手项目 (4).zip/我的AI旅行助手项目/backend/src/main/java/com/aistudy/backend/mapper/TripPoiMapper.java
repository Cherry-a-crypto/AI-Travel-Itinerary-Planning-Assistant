package com.aistudy.backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.aistudy.backend.entity.TripPoi;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TripPoiMapper extends BaseMapper<TripPoi> {
}