package com.aistudy.backend.utils;

import com.aistudy.backend.entity.Poi;
import java.util.ArrayList;
import java.util.List;

public class TspSolver {

    public static List<Poi> optimizeRoute(List<Poi> pois) {
        if (pois == null || pois.size() <= 1) return pois;

        List<Poi> optimized = new ArrayList<>();
        List<Poi> unvisited = new ArrayList<>(pois);

        Poi current = unvisited.remove(0);
        optimized.add(current);

        while (!unvisited.isEmpty()) {
            Poi nearest = null;
            double minDistance = Double.MAX_VALUE;

            for (Poi candidate : unvisited) {
                if (current.getLat() == null || current.getLng() == null ||
                        candidate.getLat() == null || candidate.getLng() == null) {
                    continue;
                }

                double dist = GeoUtils.calculateDistance(
                        current.getLat(), current.getLng(),
                        candidate.getLat(), candidate.getLng()
                );

                if (dist < minDistance) {
                    minDistance = dist;
                    nearest = candidate;
                }
            }

            if (nearest == null) {
                nearest = unvisited.get(0);
            }

            optimized.add(nearest);
            unvisited.remove(nearest);
            current = nearest;
        }

        // ========== 增加答辩炫技部分：打印前后对比 ==========
        double originalDistance = calculateTotalDistance(pois);
        double optimizedDistance = calculateTotalDistance(optimized);

        System.out.println("【算法层】优化前景点顺序: " + pois.stream().map(Poi::getName).toList());
        System.out.println("【算法层】优化后路线: " + optimized.stream().map(Poi::getName).toList());
        System.out.println(String.format("【算法层】总距离缩减：%.2f km -> %.2f km", originalDistance, optimizedDistance));

        return optimized;
    }

    // 辅助方法：计算一条路线上所有景点的总距离
    private static double calculateTotalDistance(List<Poi> route) {
        double total = 0.0;
        for (int i = 0; i < route.size() - 1; i++) {
            Poi start = route.get(i);
            Poi end = route.get(i + 1);
            if (start.getLat() != null && start.getLng() != null && end.getLat() != null && end.getLng() != null) {
                total += GeoUtils.calculateDistance(start.getLat(), start.getLng(), end.getLat(), end.getLng());
            }
        }
        return total;
    }
}