package com.aistudy.backend.controller;

import com.aistudy.backend.common.JwtUtils;
import com.aistudy.backend.common.Result;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. 查询所有用户
    @GetMapping("/list")
    public Result<List<User>> list() {
        List<User> list = userService.list();
        return Result.success(list);
    }

    // 2. 注册
    @PostMapping("/add")
    public Result<Boolean> addUser(@Valid @RequestBody User user) {
        long count = userService.lambdaQuery()
                .eq(User::getUsername, user.getUsername())
                .count();
        if (count > 0) {
            return Result.error("该账号已存在，请换一个吧");
        }
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        boolean success = userService.save(user);
        return Result.success(success);
    }

    // 3. 修改用户
    @PutMapping("/update")
    public Result<Boolean> updateUser(@Valid @RequestBody User user) {
        boolean success = userService.updateById(user);
        return Result.success(success);
    }

    // 4. 删除用户
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteUser(@PathVariable Long id) {
        boolean success = userService.removeById(id);
        return Result.success(success);
    }

    // 5. 登录（改造：返回双 Token）
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody User user) {
        User dbUser = userService.lambdaQuery()
                .eq(User::getUsername, user.getUsername())
                .one();

        if (dbUser == null) {
            return Result.error("用户不存在");
        }

        boolean isPasswordMatch = false;
        if (dbUser.getPasswordHash().startsWith("$2a$")) {
            isPasswordMatch = passwordEncoder.matches(user.getPasswordHash(), dbUser.getPasswordHash());
        } else {
            isPasswordMatch = dbUser.getPasswordHash().equals(user.getPasswordHash());
        }

        if (!isPasswordMatch) {
            return Result.error("密码错误");
        }

        // 👇 改造部分：生成双 Token
        String accessToken = jwtUtils.generateAccessToken(dbUser.getUsername());
        String refreshToken = jwtUtils.generateRefreshToken(dbUser.getUsername());

        Map<String, Object> data = new HashMap<>();
        data.put("accessToken", accessToken);
        data.put("refreshToken", refreshToken);

        dbUser.setPasswordHash(null);
        data.put("userInfo", dbUser);

        return Result.success(data);
    }

    // 👇 新增：刷新 Token 接口
    @PostMapping("/refresh")
    public Result<Map<String, Object>> refreshToken(@RequestBody Map<String, String> request) {
        String refreshToken = request.get("refreshToken");

        // 1. 校验 Refresh Token 是否合法/是否过期
        if (refreshToken == null || !jwtUtils.validateToken(refreshToken)) {
            return Result.error("刷新凭证已失效，请重新登录");
        }

        // 2. 提取用户名
        String username = jwtUtils.getUsernameFromToken(refreshToken);

        // 3. 生成新的双 Token（这里通常推荐连带 Refresh Token 一起换掉，防止 Refresh Token 被长期滥用）
        String newAccessToken = jwtUtils.generateAccessToken(username);
        String newRefreshToken = jwtUtils.generateRefreshToken(username);

        Map<String, Object> data = new HashMap<>();
        data.put("accessToken", newAccessToken);
        data.put("refreshToken", newRefreshToken);

        return Result.success(data);
    }
}