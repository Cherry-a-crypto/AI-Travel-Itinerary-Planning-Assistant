package com.aistudy.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.aistudy.backend.entity.User;

public interface UserService extends IService<User> {
}