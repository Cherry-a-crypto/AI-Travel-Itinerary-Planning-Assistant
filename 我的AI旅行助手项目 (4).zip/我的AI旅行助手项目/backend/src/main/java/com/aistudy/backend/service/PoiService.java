package com.aistudy.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.aistudy.backend.entity.Poi;

public interface PoiService extends IService<Poi> {
}