package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.entity.Poi;
import com.aistudy.backend.service.PoiService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable; // 👈 核心：就是缺了这个包的导入
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pois")
public class PoiController {

    @Autowired
    private PoiService poiService;

    // 1. 分页查询 + 关键词模糊搜索（带 Redis 缓存）
    @GetMapping("/page")
    @Cacheable(value = "poiPage", key = "#page + '-' + #size + '-' + #keyword")
    public Result<Object> pageQuery(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "5") Integer size,
            @RequestParam(required = false) String keyword
    ) {
        // 创建分页对象
        Page<Poi> pageInfo = new Page<>(page, size);

        // 构建查询条件
        LambdaQueryWrapper<Poi> wrapper = new LambdaQueryWrapper<>();

        // 如果关键词不为空，进行模糊搜索（按名称或分类）
        if (keyword != null && !keyword.trim().isEmpty()) {
            wrapper.like(Poi::getName, keyword)
                    .or()
                    .like(Poi::getCategory, keyword);
        }

        // 执行分页查询
        pageInfo = poiService.page(pageInfo, wrapper);

        // 返回结果
        return Result.success(pageInfo);
    }
}