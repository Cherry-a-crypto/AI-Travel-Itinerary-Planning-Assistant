package com.aistudy.backend.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("trip_poi")
public class TripPoi {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long tripId;
    private Long poiId;
    private Integer dayIndex;
    private Integer sortOrder;
}