package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/prep")
public class PrepController {

    // 1. 获取 AI 生成的行李清单
    @GetMapping("/packing/{tripId}")
    public Result<List<Map<String, Object>>> getPackingList(@PathVariable Long tripId) {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(createItem(1L, "身份证", "证件", true));
        list.add(createItem(2L, "充电宝", "电子", true));
        list.add(createItem(3L, "雨伞 (明日有雨)", "其他", false));
        list.add(createItem(4L, "薄外套 (降温)", "衣物", false));
        list.add(createItem(5L, "舒适的平底鞋", "衣物", false));
        return Result.success(list);
    }

    // 2. 获取记账记录数据（给 ECharts 画饼图用）
    @GetMapping("/expense/{tripId}")
    public Result<List<Map<String, Object>>> getExpenseRecords(@PathVariable Long tripId) {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(createExpense("门票", 200.00));
        list.add(createExpense("餐饮", 350.00));
        list.add(createExpense("交通", 150.00));
        list.add(createExpense("住宿", 800.00));
        return Result.success(list);
    }

    // 辅助方法，生成数据格式
    private Map<String, Object> createItem(Long id, String name, String category, boolean checked) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id); map.put("itemName", name);
        map.put("category", category); map.put("isChecked", checked);
        return map;
    }

    private Map<String, Object> createExpense(String category, Double amount) {
        Map<String, Object> map = new HashMap<>();
        map.put("category", category); map.put("amount", amount);
        return map;
    }
}