package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.Trip;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.AiTripService;
import com.aistudy.backend.service.TripService;
import com.aistudy.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trips") // 👈 如果你的路径不是这个，请改成你原来的
public class TripController {

    @Autowired
    private UserService userService;

    @Autowired
    private TripService tripService;

    @Autowired
    private AiTripService aiTripService;

    // 获取当前登录用户的方法
    private User getCurrentUser() {
        try {
            String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return userService.lambdaQuery().eq(User::getUsername, username).one();
        } catch (Exception e) {
            return null;
        }
    }

    @PostMapping("/create")
    public Result<Object> createTrip(@RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) {
            return Result.error("未登录或登录已过期");
        }

        // 1. 组装行程实体
        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false); // 默认私密

        // 👇 把前端传过来的 poiIds 塞入实体（Trip实体类里必须要有这个字段，你之前加过了）
        trip.setPoiIds(dto.getPoiIds());

        // 👇 核心：调用你完美的多表插入事务方法！！！
        boolean success = tripService.createTripWithPois(trip);

        // 2. 调用 AI 生成行程文本（保留你截图里的逻辑，这里我只写了大概）
        // String aiText = aiTripService.generateMockItinerary(trip);

        // 3. 把结果打包返回
        // 如果你不需要返回 AI 文本，直接返回 success 就行了。
        // 如果你之前有组装 map 返回，就在下面写。
        return Result.success(success);
    }
}