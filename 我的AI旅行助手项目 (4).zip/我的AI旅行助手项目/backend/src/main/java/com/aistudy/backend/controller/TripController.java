package com.aistudy.backend.controller;

import com.aistudy.backend.common.Result;
import com.aistudy.backend.dto.TripCreateDTO;
import com.aistudy.backend.entity.*;
import com.aistudy.backend.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import reactor.core.publisher.Flux;

import java.util.*;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    @Autowired
    private TripPoiService tripPoiService;

    @Autowired
    private PoiService poiService;

    @Autowired
    private UserService userService;

    @Autowired
    private TripService tripService;

    @Autowired
    private AiTripService aiTripService;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private UserFavoriteService userFavoriteService;

    // 👇 把 AI 配置正确注入到类里面
    @Value("${ai.api.key}")
    private String aiApiKey;

    @Value("${ai.api.url}")
    private String aiApiUrl;

    // 获取当前登录用户的方法
    private User getCurrentUser() {
        try {
            String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return userService.lambdaQuery().eq(User::getUsername, username).one();
        } catch (Exception e) {
            return null;
        }
    }

    // 1. 根据 ID 查询行程详情
    @GetMapping("/{id}")
    public Result<Trip> getTripById(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip != null) {
            return Result.success(trip);
        }
        return Result.error("行程不存在或已被删除");
    }

    // 2. 创建行程（普通表单提交）
    @PostMapping("/create")
    public Result<Object> createTrip(@Validated @RequestBody TripCreateDTO dto) {
        User currentUser = getCurrentUser();
        if (currentUser == null) {
            return Result.error("未登录或登录已过期");
        }

        Trip trip = new Trip();
        trip.setTitle(dto.getTitle());
        trip.setDestination(dto.getDestination());
        trip.setStartDate(dto.getStartDate());
        trip.setEndDate(dto.getEndDate());
        trip.setBudget(dto.getBudget());
        trip.setUserId(currentUser.getId());
        trip.setIsPublic(false);
        trip.setPoiIds(dto.getPoiIds());

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip);
            return Result.success(resultData);
        } else {
            return Result.error("创建行程失败，请稍后重试");
        }
    }

    // 3. 流式生成 AI 接口（前端详情页调这个）
    @GetMapping(value = "/stream/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamAiText(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) {
            return Flux.just("行程不存在");
        }
        return aiTripService.streamItinerary(trip);
    }

    // 4. 获取行程关联的真实景点列表（按天分组）
    @GetMapping("/{id}/details")
    public Result<Map<Integer, List<Poi>>> getTripDetails(@PathVariable Long id) {
        List<TripPoi> tripPois = tripPoiService.lambdaQuery()
                .eq(TripPoi::getTripId, id)
                .orderByAsc(TripPoi::getDayIndex)
                .orderByAsc(TripPoi::getSortOrder)
                .list();

        Map<Integer, List<Poi>> resultMap = new java.util.LinkedHashMap<>();

        for (TripPoi tp : tripPois) {
            Poi poi = poiService.getById(tp.getPoiId());
            if (poi != null) {
                resultMap.computeIfAbsent(tp.getDayIndex(), k -> new ArrayList<>()).add(poi);
            }
        }
        return Result.success(resultMap);
    }

    // 5. 分享行程 (FR-14)
    @PostMapping("/{id}/share")
    public Result<String> shareTrip(@PathVariable Long id) {
        Trip trip = tripService.getById(id);
        if (trip == null) return Result.error("行程不存在");
        trip.setIsPublic(true);
        tripService.updateById(trip);
        return Result.success("行程已公开分享");
    }

    // 6. 收藏行程 (FR-15 落库 + Redis计数)
    @PostMapping("/{id}/favorite")
    public Result<String> favoriteTrip(@PathVariable Long id) {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");

        boolean exists = userFavoriteService.lambdaQuery()
                .eq(UserFavorite::getUserId, user.getId())
                .eq(UserFavorite::getTripId, id)
                .exists();
        if (exists) return Result.error("您已经收藏过该行程啦");

        UserFavorite fav = new UserFavorite();
        fav.setUserId(user.getId());
        fav.setTripId(id);
        userFavoriteService.save(fav);

        Long count = stringRedisTemplate.opsForValue().increment("trip:favorite:count:" + id);
        return Result.success("收藏成功！当前热度：" + count);
    }

    // 7. 获取天气 (FR-10)
    @GetMapping("/weather")
    public Result<String> getWeather(@RequestParam String city) {
        String[] weathers = {"今日小雨转阴 18~23°C，已调整<strong>室内景点优先</strong>", "明日转晴 16~26°C，已将长城行程调整至<strong>上午出发</strong>", "空气质量优，已为你加入<strong>景山日落观景</strong>环节"};
        return Result.success(weathers[new java.util.Random().nextInt(weathers.length)]);
    }

    // 8. 自然语言意图解析并生成行程 (核心功能)
    // 8. 自然语言意图解析并生成行程 (核心功能，带降级兜底)
    @PostMapping("/generate-by-intent")
    public Result<Object> generateByIntent(@RequestBody Map<String, String> requestBody) {
        String userIntent = requestBody.get("intent");
        if (userIntent == null || userIntent.isEmpty()) {
            return Result.error("请输入旅行需求");
        }

        // 👇 核心：先查一下当前用户，没登录直接打回
        User currentUser = getCurrentUser();
        if (currentUser == null) return Result.error("未登录");

        String destination = "北京";
        Integer days = 3;
        List<Long> finalPoiIds = new ArrayList<>();

        try {
            // 1. 尝试调用大模型解析意图（有可能会超时或网络异常）
            Map<String, Object> intentData = aiTripService.parseIntent(userIntent);
            destination = (String) intentData.getOrDefault("city", "北京");
            days = (Integer) intentData.getOrDefault("days", 3);

            // 2. 尝试查库
            List<Poi> cityPois = poiService.lambdaQuery()
                    .eq(Poi::getCity, destination)
                    .last("LIMIT 3")
                    .list();

            if (!cityPois.isEmpty()) {
                for (Poi p : cityPois) finalPoiIds.add(p.getId());
            } else {
                // 3. 库里没有，尝试让 AI 生成
                List<Poi> aiPois = aiTripService.generatePoisByCity(destination);
                if (!aiPois.isEmpty()) {
                    poiService.saveBatch(aiPois);
                    for (Poi p : aiPois) finalPoiIds.add(p.getId());
                }
            }
        } catch (Exception e) {
            // 🚨 AI 挂了或者数据库报错了，直接在这里降级！
            System.out.println("【AI降级预警】大模型接口异常，已启用降级兜底方案：" + e.getMessage());

            // 兜底方案：直接拿数据库里的3个景点凑一个行程
            List<Poi> fallbackPois = poiService.lambdaQuery().last("LIMIT 3").list();
            for (Poi p : fallbackPois) {
                finalPoiIds.add(p.getId());
            }
        }

        // 4. 终极兜底保证
        if (finalPoiIds.isEmpty()) {
            return Result.error("系统繁忙，且数据库暂无备用景点");
        }

        // 5. 组装行程
        Trip trip = new Trip();
        trip.setTitle(destination + " " + days + "日游");
        trip.setDestination(destination);
        trip.setUserId(currentUser.getId());
        trip.setBudget(new java.math.BigDecimal("3000"));
        trip.setIsPublic(false);
        trip.setPoiIds(finalPoiIds);

        boolean success = tripService.createTripWithPois(trip);

        if (success) {
            Map<String, Object> resultData = new HashMap<>();
            resultData.put("trip", trip);
            return Result.success(resultData);
        }
        return Result.error("创建行程失败，请稍后重试");
    }
    // 9. 接收前端拖拽后的新顺序并重排
    @PutMapping("/{id}/items")
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public Result<String> reorderTripItems(
            @PathVariable Long id,
            @RequestBody java.util.Map<String, java.util.List<Long>> details) {

        // 1. 先彻底清空该行程下的所有景点关联
        tripPoiService.lambdaUpdate().eq(TripPoi::getTripId, id).remove();

        // 2. 按照前端传来的最新分组，重新插入
        if (details != null && !details.isEmpty()) {
            java.util.List<TripPoi> newList = new java.util.ArrayList<>();

            // 遍历每一天（比如 key 是 "1", "2", "3"）
            details.forEach((dayStr, poiIds) -> {
                if (poiIds != null && !poiIds.isEmpty()) {
                    Integer dayIndex = Integer.parseInt(dayStr);
                    for (int i = 0; i < poiIds.size(); i++) {
                        TripPoi tp = new TripPoi();
                        tp.setTripId(id);
                        tp.setPoiId(poiIds.get(i));
                        tp.setSortOrder(i + 1); // 对应的排序值
                        tp.setDayIndex(dayIndex); // 对应的天数
                        newList.add(tp);
                    }
                }
            });
            tripPoiService.saveBatch(newList);
        }
        return Result.success("跨天路线重排成功");
    }
    // 👇 新增：保存游记并发布到发现页
    @PostMapping("/{id}/publish-post")
    public Result<String> publishPost(@PathVariable Long id, @RequestBody Map<String, String> requestBody) {
        Trip trip = tripService.getById(id);
        if (trip == null) return Result.error("行程不存在");

        // 1. 把 AI 生成的游记存入数据库
        trip.setPostContent(requestBody.get("content"));
        // 2. 顺便把它设为公开
        trip.setIsPublic(true);

        boolean success = tripService.updateById(trip);
        if (success) {
            return Result.success("游记发布成功！");
        }
        return Result.error("发布失败");
    }
    // 10. 发现页：获取所有公开的行程 (FR-14)
    // 10. 发现页：获取所有公开的行程 (带点赞数和动态封面)
    @GetMapping("/discover")
    public Result<List<Map<String, Object>>> discoverTrips() {
        List<Trip> publicTrips = tripService.lambdaQuery()
                .eq(Trip::getIsPublic, true)
                .orderByDesc(Trip::getId)
                .list();

        List<Map<String, Object>> resultList = new ArrayList<>();
        for (Trip trip : publicTrips) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", trip.getId());
            map.put("title", trip.getTitle());
            map.put("destination", trip.getDestination());
            map.put("startDate", trip.getStartDate());
            map.put("endDate", trip.getEndDate());
            map.put("budget", trip.getBudget());
            map.put("postContent", trip.getPostContent());
            map.put("userId", trip.getUserId());

            // 1. 获取真实的点赞数（从 Redis 取，如果没有就默认为 0）
            String countStr = stringRedisTemplate.opsForValue().get("trip:favorite:count:" + trip.getId());
            map.put("favoriteCount", countStr != null ? Integer.parseInt(countStr) : 0);

            // 2. 动态生成高德静态地图封面图（拿行程里的第一个景点，如果没有就默认北京市中心）
            // 注意：替换为你自己的高德 Web服务 Key
            String amapKey = "88f1f165d50a4fa7ba05670cf4f7eb7c";

            // 默认坐标（北京）
            String lng = "116.397";
            String lat = "39.916";

            // 尝试从 trip 关联的 poi 里找真实坐标
            List<TripPoi> tripPois = tripPoiService.lambdaQuery().eq(TripPoi::getTripId, trip.getId()).last("LIMIT 1").list();
            if (!tripPois.isEmpty()) {
                Poi firstPoi = poiService.getById(tripPois.get(0).getPoiId());
                if (firstPoi != null && firstPoi.getLng() != null) {
                    lng = firstPoi.getLng().toString();
                    lat = firstPoi.getLat().toString();
                }
            }
            // 拼接高德静态地图API URL (带一个红色的标记)
            String coverUrl = String.format(
                    "https://restapi.amap.com/v3/staticmap?location=%s,%s&zoom=11&size=400*250&markers=mid,,A:%s,%s&key=%s",
                    lng, lat, lng, lat, amapKey
            );
            map.put("coverImage", coverUrl);

            resultList.add(map);
        }

        return Result.success(resultList);
    }
    // 11. 我的页：获取当前用户创建的行程
    @GetMapping("/my-trips")
    public Result<List<Trip>> getMyTrips() {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");
        List<Trip> myTrips = tripService.lambdaQuery()
                .eq(Trip::getUserId, user.getId())
                .orderByDesc(Trip::getId)
                .list();
        return Result.success(myTrips);
    }

    // 12. 我的页：获取当前用户收藏的行程
    @GetMapping("/my-favorites")
    public Result<List<Trip>> getMyFavorites() {
        User user = getCurrentUser();
        if (user == null) return Result.error("未登录");

        // 1. 查出用户所有收藏记录
        List<UserFavorite> favorites = userFavoriteService.lambdaQuery()
                .eq(UserFavorite::getUserId, user.getId())
                .list();

        if (favorites == null || favorites.isEmpty()) {
            return Result.success(new ArrayList<>());
        }

        // 2. 提取非空的 tripId
        List<Long> tripIds = new ArrayList<>();
        for (UserFavorite fav : favorites) {
            if (fav.getTripId() != null) {
                tripIds.add(fav.getTripId());
            }
        }

        if (tripIds.isEmpty()) {
            return Result.success(new ArrayList<>());
        }

        // 3. 使用 lambdaQuery 替换 listByIds，彻底告别 SQL 报错
        List<Trip> favoriteTrips = tripService.lambdaQuery()
                .in(Trip::getId, tripIds)
                .list();

        return Result.success(favoriteTrips);
    }

    // 👇👇👇 核心修复：真实的 AI 游记生成接口（放在了类里面） 👇👇👇
    @GetMapping("/{id}/generate-post")
    public Result<String> generatePost(@PathVariable Long id) {
        try {
            // 1. 查出行程基本信息
            Trip trip = tripService.getById(id);
            if (trip == null) return Result.error("行程不存在");

            // 2. 拼装 Prompt
            // 注意：因为你的 Trip 实体类可能没有 getDays()，我在这里用 3 天作为兜底
            String prompt = String.format(
                    "你是一个资深的旅行博主，请根据以下行程信息写一篇小红书风格的游记。\n" +
                            "目的地：%s\n行程天数：3天\n" +
                            "要求：字数200字左右，带Emoji，包含避坑指南和赞美AI规划的感受，并附带3个话题标签。",
                    trip.getDestination()
            );

            // 3. 构造请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(aiApiKey);

            // 4. 构造请求体 (DeepSeek 的格式和 OpenAI 兼容)
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("model", "deepseek-chat");

            List<Map<String, String>> messages = new ArrayList<>();
            Map<String, String> userMessage = new HashMap<>();
            userMessage.put("role", "user");
            userMessage.put("content", prompt);
            messages.add(userMessage);
            requestBody.put("messages", messages);
            requestBody.put("temperature", 0.7);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            RestTemplate restTemplate = new RestTemplate();

            // 5. 发起真实网络请求
            ResponseEntity<Map> response = restTemplate.postForEntity(aiApiUrl, entity, Map.class);
            Map<String, Object> body = response.getBody();

            // 6. 解析大模型返回的文本
            if (body != null && body.containsKey("choices")) {
                List<Map<String, Object>> choices = (List<Map<String, Object>>) body.get("choices");
                if (!choices.isEmpty()) {
                    Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
                    String content = (String) message.get("content");
                    return Result.success(content);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("AI 撰写游记失败：" + e.getMessage());
        }
        return Result.error("AI 服务异常，请稍后再试");
    }
}