package com.aistudy.backend.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.aistudy.backend.entity.TripPoi;
public interface TripPoiService extends IService<TripPoi> {}