package com.aistudy.backend.config;

import com.aistudy.backend.common.JwtUtils;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UserService userService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        // 👇👇👇 核心修改：白名单放行（解决控制台疯狂报错的问题）👇👇👇
        String requestURI = request.getRequestURI();
        // 如果是登录、注册、地图周边、POI查询，直接放行，不去解析 Token
        if (requestURI.contains("/api/users/login") ||
                requestURI.contains("/api/users/add") ||
                requestURI.contains("/api/map/") ||
                requestURI.contains("/api/pois/")) {
            filterChain.doFilter(request, response);
            return; // 直接返回，结束当前过滤器，不去校验 Token
        }

        // 1. 获取请求头
        String authHeader = request.getHeader("Authorization");

        // 2. 如果没有 Token，或者不是以 Bearer 开头，直接放行！
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        // 3. 如果有 Token，才去解析
        String token = authHeader.substring(7);
        try {
            String username = jwtUtils.getUsernameFromToken(token);
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

                // 查用户、塞权限
                User dbUser = userService.lambdaQuery().eq(User::getUsername, username).one();

                if (dbUser != null) {
                    // 封装权限
                    SimpleGrantedAuthority authority = new SimpleGrantedAuthority(dbUser.getRole());

                    // 构建认证对象
                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(username, null, Collections.singletonList(authority));

                    // 塞进 SecurityContextHolder
                    SecurityContextHolder.getContext().setAuthentication(authentication);

                    System.out.println("【拦截器】Token 验证成功，用户: " + username + "，权限: " + dbUser.getRole());
                }
            }
        } catch (Exception e) {
            System.out.println("【拦截器】Token 解析失败，无效或过期！");
        }

        // 4. 最后一定要放行请求
        filterChain.doFilter(request, response);
    }
}