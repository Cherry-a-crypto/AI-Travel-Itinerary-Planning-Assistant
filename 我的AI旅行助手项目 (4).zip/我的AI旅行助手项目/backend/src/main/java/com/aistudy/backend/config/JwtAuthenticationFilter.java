package com.aistudy.backend.config;

import com.aistudy.backend.common.JwtUtils;
import com.aistudy.backend.entity.User;
import com.aistudy.backend.service.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // 1. 直接获取请求头
        String authHeader = request.getHeader("Authorization");

        // 2. 核心：如果没有 Token，或者不是以 Bearer 开头，直接放行！！！
        // （交给后面的 SecurityConfig 去决定是允许匿名访问，还是要求认证）
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response); // 👈 必须加这句，放行请求！
            return; // 👈 结束当前拦截器
        }

        // 3. 如果有 Token，才去解析
        String token = authHeader.substring(7);
        try {
            String username = jwtUtils.getUsernameFromToken(token);
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                // ... 查用户、塞权限 ...
                System.out.println("【拦截器】Token 验证成功，用户: " + username);
            }
        } catch (Exception e) {
            // 4. 就算 Token 过期或解析失败，也不要直接拦截，让它往下走，Security 会处理
            System.out.println("【拦截器】Token 解析失败，无效或过期！");
        }

        // 5. 最后一定要放行请求
        filterChain.doFilter(request, response);
    }
    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UserService userService; // 👈 必须注入 UserService 才能查数据库


}