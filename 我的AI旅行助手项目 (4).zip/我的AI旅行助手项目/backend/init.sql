DROP DATABASE IF EXISTS ai_travel;
CREATE DATABASE ai_travel;
USE ai_travel;

-- 1. 用户表
CREATE TABLE `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `password_hash` VARCHAR(255) NOT NULL COMMENT '密码哈希',
  `nickname` VARCHAR(50) DEFAULT NULL COMMENT '昵称',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 2. 景点POI表
CREATE TABLE `poi` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'POI ID',
  `name` VARCHAR(100) NOT NULL COMMENT '景点名称',
  `city` VARCHAR(50) NOT NULL COMMENT '城市',
  `address` VARCHAR(255) DEFAULT NULL COMMENT '详细地址',
  `lat` DECIMAL(10,6) NOT NULL COMMENT '纬度',
  `lng` DECIMAL(10,6) NOT NULL COMMENT '经度',
  `category` VARCHAR(50) DEFAULT NULL COMMENT '分类',
  `open_time` VARCHAR(100) DEFAULT NULL COMMENT '开放时间',
  `duration_min` INT DEFAULT 60 COMMENT '建议游览分钟数',
  `ticket_price` DECIMAL(10,2) DEFAULT 0.00 COMMENT '门票价格',
  PRIMARY KEY (`id`),
  KEY `idx_poi_city_category` (`city`, `category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='景点POI表';

-- 3. 行程表
CREATE TABLE `trip` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '行程ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `title` VARCHAR(100) NOT NULL COMMENT '行程标题',
  `destination` VARCHAR(100) NOT NULL COMMENT '目的地',
  `start_date` DATE DEFAULT NULL COMMENT '开始日期',
  `end_date` DATE DEFAULT NULL COMMENT '结束日期',
  `budget` DECIMAL(10,2) DEFAULT 0.00 COMMENT '预算',
  `is_public` TINYINT(1) DEFAULT 1 COMMENT '是否公开',
  PRIMARY KEY (`id`),
  KEY `idx_trip_user` (`user_id`),
  CONSTRAINT `fk_trip_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行程表';

-- 4. 行程每日表
CREATE TABLE `trip_day` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '每日ID',
  `trip_id` BIGINT NOT NULL COMMENT '行程ID',
  `day_index` INT NOT NULL COMMENT '第几天(1,2,3...)',
  `date` DATE DEFAULT NULL COMMENT '具体日期',
  PRIMARY KEY (`id`),
  KEY `idx_trip_day` (`trip_id`),
  CONSTRAINT `fk_day_trip` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行程每日表';

-- 5. 行程明细项表
CREATE TABLE `itinerary_item` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '明细ID',
  `trip_day_id` BIGINT NOT NULL COMMENT '每日ID',
  `poi_id` BIGINT NOT NULL COMMENT 'POI ID',
  `sort_order` INT NOT NULL COMMENT '排序',
  `start_time` TIME DEFAULT NULL COMMENT '开始时间',
  `end_time` TIME DEFAULT NULL COMMENT '结束时间',
  `cost` DECIMAL(10,2) DEFAULT 0.00 COMMENT '花费',
  PRIMARY KEY (`id`),
  KEY `idx_item_day_sort` (`trip_day_id`, `sort_order`),
  CONSTRAINT `fk_item_day` FOREIGN KEY (`trip_day_id`) REFERENCES `trip_day` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_item_poi` FOREIGN KEY (`poi_id`) REFERENCES `poi` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行程明细项表';

-- 6. 交通路段表
CREATE TABLE `transport_segment` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '路段ID',
  `trip_id` BIGINT NOT NULL COMMENT '行程ID',
  `from_item_id` BIGINT NOT NULL COMMENT '起点明细ID',
  `to_item_id` BIGINT NOT NULL COMMENT '终点明细ID',
  `mode` VARCHAR(20) DEFAULT NULL COMMENT '交通方式',
  `duration_min` INT DEFAULT NULL COMMENT '耗时(分钟)',
  `distance_km` DECIMAL(6,2) DEFAULT NULL COMMENT '距离(公里)',
  PRIMARY KEY (`id`),
  KEY `idx_transport_trip` (`trip_id`),
  CONSTRAINT `fk_transport_trip` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交通路段表';

-- 7. 用户收藏表
CREATE TABLE `user_favorite` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL,
  `trip_id` BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_trip` (`user_id`, `trip_id`),
  CONSTRAINT `fk_fav_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fav_trip` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏表';
-- 1. 临时关闭外键检查
SET FOREIGN_KEY_CHECKS = 0;

-- 2. 清空 poi 表
TRUNCATE TABLE poi;

-- 3. 重新插入 3 条唯一的初始数据
INSERT INTO poi (name, city, address, lat, lng, category, open_time, duration_min, ticket_price) VALUES
('故宫博物院', '北京', '东城区景山前街4号', 39.9163, 116.3972, '历史文化', '08:30-17:00', 180, 60.00),
('八达岭长城', '北京', '延庆区G6京藏高速58号出口', 40.3597, 116.0200, '世界遗产', '06:30-19:00', 240, 40.00),
('颐和园', '北京', '海淀区新建宫门路19号', 39.9999, 116.2751, '皇家园林', '06:30-18:00', 180, 30.00);

-- 4. 重新开启外键检查
SET FOREIGN_KEY_CHECKS = 1;

-- 5. 查询确认
SELECT * FROM poi;