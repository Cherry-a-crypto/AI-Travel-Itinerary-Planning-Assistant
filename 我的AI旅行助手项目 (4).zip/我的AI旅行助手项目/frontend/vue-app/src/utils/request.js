import axios from 'axios'

// 1. 创建 axios 实例，指向你的后端地址
const request = axios.create({
  baseURL: 'http://localhost:8080', // 👈 你的后端地址
  timeout: 5000 // 5秒超时
})

// 2. 请求拦截器：每次发请求前，自动把 Token 塞进请求头
request.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token')
    if (token) {
      // 注意 Bearer 后面有个空格
      config.headers['Authorization'] = 'Bearer ' + token 
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 3. 响应拦截器：直接剥离外层，返回后端的真实数据（比如 code, data 等）
request.interceptors.response.use(
  response => {
    return response.data 
  },
  error => {
    console.error('请求报错了:', error)
    return Promise.reject(error)
  }
)

export default request