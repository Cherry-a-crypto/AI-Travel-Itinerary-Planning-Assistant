import axios from 'axios'

// 1. 创建 axios 实例
const request = axios.create({
  baseURL: 'http://localhost:8080', 
  timeout: 5000 
})

// 2. 请求拦截器
request.interceptors.request.use(
  config => {
    // 👇 核心修复：这里必须取 accessToken
    const token = localStorage.getItem('accessToken') 
    
    if (token) {
      // 👇 这里直接用上面取到的 token 变量
      config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 3. 响应拦截器
request.interceptors.response.use(
  response => {
    return response.data 
  },
  error => {
    console.error('请求报错了:', error)
    return Promise.reject(error)
  }
)

export default request