import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useUserStore = defineStore('user', () => {
  const token = ref('')
  const username = ref('')

  function setUser(name, userToken) {
    username.value = name
    token.value = userToken
  }

  function logout() {
    username.value = ''
    token.value = ''
  }

  return { token, username, setUser, logout }
})