<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()

// 表单绑定的数据
const registerForm = ref({
  username: '',
  passwordHash: '',
  nickname: ''
})

// 表单的引用（用于触发验证）
const formRef = ref(null)

// Element Plus 的表单验证规则
const rules = {
  username: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { min: 3, max: 20, message: '账号长度在 3 到 20 个字符', trigger: 'blur' }
  ],
  passwordHash: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码不能少于 6 位', trigger: 'blur' }
  ],
  nickname: [
    { required: true, message: '请输入昵称', trigger: 'blur' }
  ]
}

const handleRegister = async () => {
  if (!formRef.value) return

  // 1. 触发前端表单验证
  await formRef.value.validate(async (valid) => {
    if (valid) {
      try {
        // 2. 验证通过，发送请求给后端
        const res = await request.post('/users/add', registerForm.value)
        
        if (res.code === 200) {
          ElMessage.success('注册成功！请登录')
          router.push('/') // 注册成功跳回登录页
        } else {
          ElMessage.error(res.message)
        }
      } catch (error) {
        ElMessage.error('注册失败，账号可能已存在')
      }
    } else {
      ElMessage.warning('请按要求填写表单')
      return false
    }
  })
}
</script>

<template>
  <div class="login-bg min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/90 shadow-xl mb-4 text-3xl">📝</div>
        <h1 class="text-3xl font-bold text-white tracking-wide drop-shadow-lg">注册新账号</h1>
      </div>

      <div class="bg-white/10 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl p-8">
        <!-- 使用 Element Plus 的 Form 组件 -->
        <el-form ref="formRef" :model="registerForm" :rules="rules" label-position="top">
          <el-form-item label="账号" prop="username">
            <el-input v-model="registerForm.username" placeholder="请输入账号" size="large" />
          </el-form-item>

          <el-form-item label="密码" prop="passwordHash">
            <el-input v-model="registerForm.passwordHash" type="password" placeholder="请输入密码" size="large" show-password />
          </el-form-item>

          <el-form-item label="昵称" prop="nickname">
            <el-input v-model="registerForm.nickname" placeholder="请输入昵称" size="large" />
          </el-form-item>

          <el-button type="primary" size="large" class="w-full !py-3 !text-lg !rounded-xl !font-semibold mt-4" @click="handleRegister">
            注 册
          </el-button>
          
          <div class="text-center mt-4">
            <span @click="router.push('/')" class="text-sm text-sky-200 cursor-pointer hover:text-white">已有账号？去登录</span>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 复用之前的星空背景 */
.login-bg {
  background-image:
    linear-gradient(rgba(6,16,38,.35), rgba(6,16,38,.55)),
    url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80');
  background-size: cover;
  background-position: center;
}
:deep(.el-input__wrapper) {
  background-color: rgba(255, 255, 255, 0.15) !important;
  box-shadow: none !important;
  border: 1px solid rgba(255, 255, 255, 0.3) !important;
}
:deep(.el-input__inner) {
  color: #fff !important;
}
:deep(.el-form-item__label) {
  color: #e0f2fe !important;
}
</style>