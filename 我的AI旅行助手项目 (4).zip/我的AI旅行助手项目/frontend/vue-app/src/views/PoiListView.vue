<script setup>
import { ref, onMounted } from 'vue'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

// 搜索关键词
const keyword = ref('')
// 表格数据
const tableData = ref([])
// 分页数据
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(5)

// 获取数据的方法
const fetchData = async () => {
  try {
    const res = await request.get('/pois/page', {
      params: {
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        keyword: keyword.value
      }
    })
    if (res.code === 200) {
      tableData.value = res.data.records
      total.value = res.data.total
    }
  } catch (error) {
    ElMessage.error('获取数据失败，请检查登录状态')
    console.error(error)
  }
}

// 翻页事件
const handlePageChange = (newPage) => {
  pageNum.value = newPage
  fetchData()
}

// 页面加载时请求一次数据
onMounted(() => {
  fetchData()
})
</script>

<template>
  <div class="p-8 max-w-6xl mx-auto min-h-screen bg-gray-50">
    <h2 class="text-2xl font-bold mb-6 text-slate-800">景点数据管理</h2>

    <!-- 搜索区域 -->
    <div class="mb-4 flex gap-2">
      <el-input 
        v-model="keyword" 
        placeholder="请输入景点名称或分类进行搜索" 
        style="width: 300px;" 
        clearable
        @keyup.enter="fetchData"
      />
      <el-button type="primary" @click="fetchData">搜索</el-button>
    </div>

    <!-- 表格区域 -->
    <el-table :data="tableData" border style="width: 100%; margin-bottom: 20px;" v-loading="!tableData.length">
      <el-table-column prop="id" label="ID" width="80" align="center" />
      <el-table-column prop="name" label="景点名称" width="200" />
      <el-table-column prop="city" label="城市" width="120" />
      <el-table-column prop="category" label="分类" width="120" />
      <el-table-column prop="address" label="详细地址" show-overflow-tooltip />
      <el-table-column prop="ticketPrice" label="门票价格" width="120" align="center">
        <template #default="scope">
          <span class="text-sky-600 font-bold">¥{{ scope.row.ticketPrice }}</span>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页区域 -->
    <div class="flex justify-end mt-4">
      <el-pagination
        background
        layout="total, prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="pageNum"
        @current-change="handlePageChange"
      />
    </div>
  </div>
</template>