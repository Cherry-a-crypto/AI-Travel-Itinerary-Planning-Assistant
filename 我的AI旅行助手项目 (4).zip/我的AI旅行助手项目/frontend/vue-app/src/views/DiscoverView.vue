<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()
const trips = ref([])
const isLoading = ref(true)

const fetchTrips = async () => {
  try {
    const res = await request.get('/api/trips/discover')
    if (res.code === 200) trips.value = res.data
  } catch (error) {
    ElMessage.error('获取发现列表失败')
  } finally {
    isLoading.value = false
  }
}

onMounted(() => {
  fetchTrips()
})

// 👇 核心：真实的点赞/收藏逻辑
const handleFavorite = async (trip, event) => {
  // 阻止事件冒泡，防止点击爱心时跳进详情页
  event.stopPropagation()
  
  try {
    const res = await request.post(`/api/trips/${trip.id}/favorite`)
    if (res.code === 200) {
      ElMessage.success(res.message)
      // 真实数据更新
      trip.favoriteCount += 1 
    } else {
      ElMessage.warning(res.message) // 比如：已经收藏过啦
    }
  } catch (error) {
    ElMessage.error('收藏失败')
  }
}
</script>

<template>
  <div class="min-h-screen bg-[#f7f9fa]">
    <!-- 顶部导航栏 -->
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold text-sky-600">发现社区</span>
        </div>
        <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <span @click="router.push('/home')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">首页</span>
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-50">发现</a>
          <span @click="router.push('/mine')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">我的</span>
        </div>
        <button @click="router.push('/')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white transition">退出</button>
      </div>
    </nav>

    <!-- 主体内容 -->
    <main class="max-w-6xl mx-auto px-6 py-8">
      <h1 class="text-3xl font-extrabold text-slate-800 mb-8 flex items-center gap-2">🌍 大家都在去哪玩？</h1>
      
      <div v-if="isLoading" class="text-center text-sky-500 py-20 flex flex-col items-center">
        <span class="text-4xl mb-4 animate-bounce">⏳</span>
        正在加载社区行程...
      </div>
      
      <div v-else-if="trips.length === 0" class="text-center text-slate-400 py-20 bg-white rounded-2xl shadow-sm">
        暂无公开的行程，快去生成一个并点击“分享”吧！
      </div>

      <!-- 瀑布流卡片列表 -->
      <div v-else class="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
        <div 
          v-for="t in trips" 
          :key="t.id" 
          class="break-inside-avoid bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-gray-100 group flex flex-col" 
          @click="router.push(`/detail?id=${t.id}`)"
        >
          <!-- 动态高德地图封面 -->
          <div class="relative h-40 w-full overflow-hidden bg-gray-100">
            <img :src="t.coverImage" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="route-map" />
            <span class="absolute top-3 right-3 text-xs bg-black/60 backdrop-blur-md text-white px-2 py-1 rounded-md">
              📍 {{ t.destination }}
            </span>
            <span class="absolute bottom-3 left-3 text-xs bg-white/90 text-sky-600 px-2 py-1 rounded-md font-bold shadow-sm">
              AI 专属路线
            </span>
          </div>

          <!-- 卡片内容 -->
          <div class="p-5 flex-1">
            <h3 class="text-lg font-bold text-slate-800 line-clamp-2 leading-snug mb-3">
              {{ t.title }}
            </h3>
            
            <!-- 游记内容摘要 -->
            <div v-if="t.postContent" class="relative">
              <p class="text-sm text-slate-600 leading-relaxed line-clamp-4 whitespace-pre-wrap">
                {{ t.postContent }}
              </p>
            </div>
            <div v-else class="text-sm text-slate-400 italic py-4 text-center bg-gray-50 rounded-lg">
              作者正在奋笔疾书中...
            </div>
          </div>

          <!-- 底部互动区 -->
          <div class="px-5 pb-4 flex items-center justify-between border-t border-gray-50 pt-3">
            <div class="flex items-center gap-2">
              <div class="w-6 h-6 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center text-xs font-bold">
                {{ t.userId ? 'U' : 'A' }}
              </div>
              <span class="text-xs text-slate-500">旅行者_{{ t.userId || '匿名' }}</span>
            </div>
            
            <!-- 👇 真实的互动按钮，带点击动画 👇 -->
            <div class="flex items-center gap-4 text-xs text-slate-400">
              <button 
                @click="handleFavorite(t, $event)"
                class="flex items-center gap-1.5 hover:text-red-500 transition-colors group/btn"
              >
                <span class="text-base group-active/btn:scale-150 transition-transform duration-200">❤️</span>
                <span class="font-medium">{{ t.favoriteCount || 0 }}</span>
              </button>
              <span class="flex items-center gap-1 hover:text-sky-500 transition-colors cursor-pointer">
                💬 {{ Math.floor(Math.random() * 20) + 1 }}
              </span>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>