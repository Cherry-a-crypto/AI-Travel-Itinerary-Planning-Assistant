<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
// 👇 这里就是你刚刚改的第一行，完全正确！
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const password = ref('')
const isLoading = ref(false)

const handleLogin = async () => {
  if (!userStore.username || !password.value) {
    ElMessage.warning('请输入账号和密码')
    return
  }

  isLoading.value = true
  try {
    // 👇 这里用的是 request，而不是 axios 了
    const res = await request.post('/users/login', {
      username: userStore.username,
      passwordHash: password.value
    })

    // 👇 因为 request.js 里已经帮你解包了 response.data，所以直接拿 res.code 即可
    if (res.code === 200) {
      ElMessage.success('登录成功！')
      
      // 存用户信息
      userStore.setUser(res.data.userInfo.username, res.data.token)
      
      // 👇 把 token 存进本地存储，防止刷新页面丢失
      localStorage.setItem('token', res.data.token)
      
      // 跳转首页
      router.push('/home')
    } else {
      ElMessage.error(res.message) 
    }
  } catch (error) {
    ElMessage.error('网络异常，请确保后端已启动')
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="login-bg min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/90 shadow-xl mb-4 text-3xl">✈️</div>
        <h1 class="text-3xl font-bold text-white tracking-wide drop-shadow-lg">AI旅行行程规划助手</h1>
      </div>

      <div class="bg-white/10 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl p-8">
        <div class="space-y-4">
          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">账号</label>
            <el-input v-model="userStore.username" placeholder="请输入手机号 / 邮箱" size="large" />
          </div>
          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">密码</label>
            <el-input v-model="password" type="password" placeholder="请输入密码" size="large" show-password />
          </div>
          <!-- 这里绑定了点击事件 handleLogin -->
          <el-button type="primary" size="large" class="w-full !py-3 !text-lg !rounded-xl !font-semibold" @click="handleLogin">
            登录 / 注册
          </el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-bg {
  background-image: linear-gradient(rgba(6,16,38,.35), rgba(6,16,38,.55)), url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80');
  background-size: cover; background-position: center;
}
:deep(.el-input__wrapper) { background-color: rgba(255, 255, 255, 0.15) !important; box-shadow: none !important; border: 1px solid rgba(255, 255, 255, 0.3) !important; }
:deep(.el-input__inner) { color: #fff !important; }
</style>