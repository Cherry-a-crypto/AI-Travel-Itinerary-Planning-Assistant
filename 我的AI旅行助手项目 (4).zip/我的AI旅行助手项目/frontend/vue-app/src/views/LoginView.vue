<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
// 👇 这里就是你刚刚改的第一行，完全正确！
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()
// 如果你不需要 userStore 了，这行也可以删掉，不过留着也不影响
const userStore = useUserStore() 

// 👇 1. 只声明一次 username 和 password
const username = ref('')
const password = ref('')
const isLoading = ref(false)

const handleLogin = async () => {
  // 👇 2. 校验逻辑里，一定要用刚才声明的 username.value 和 password.value
  if (!username.value || !password.value) {
    ElMessage.warning('请输入账号和密码')
    return
  }

  isLoading.value = true
  try {
    // 👇 3. 发送请求（你截图里这段写得是对的，保持原样）
    const res = await request.post('/api/users/login', {
      username: username.value,
      passwordHash: password.value
    })
    
    // ... 下面是你写的 if (res.code === 200) 的逻辑，不用动 ...

    // 👇 因为 request.js 里已经帮你解包了 response.data，所以直接拿 res.code 即可
          if (res.code === 200) {
        ElMessage.success('登录成功！')
        
        // 1. 👇 必须加这行：把后端的 token 存到浏览器的本地存储里
        // (你之前在 request.js 拦截器里就是靠拿这个 token 才能通过后端的鉴权的)
        localStorage.setItem('token', res.data.token)
        
        // 2. 存用户信息
        userStore.setUser(res.data.userInfo) 
        
        // 3. 👇 必须加这行：登录成功后，立刻跳转回主页
        // (请确保你的 router/index.js 里配置了 '/' 或 '/home')
        router.push('/home') 
      } else {
        ElMessage.error(res.message || '登录失败')
      }
    }
    catch (error) {
      // 👇 加上这个，处理网络异常或后端崩溃
      console.error('请求失败:', error)
      ElMessage.error('网络异常，请检查后端服务是否启动')
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="login-bg min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/90 shadow-xl mb-4 text-3xl">✈️</div>
        <h1 class="text-3xl font-bold text-white tracking-wide drop-shadow-lg">AI旅行行程规划助手</h1>
      </div>

      <div class="bg-white/10 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl p-8">
        <div class="space-y-4">
          <!-- 账号输入框（只留这一个！） -->
          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">账号</label>
            <el-input v-model="username" placeholder="请输入手机号 / 邮箱" size="large" />
          </div>

          <!-- 密码输入框（只留这一个！） -->
          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">密码</label>
            <el-input v-model="password" type="password" placeholder="请输入密码" size="large" show-password />
          </div>
        </div>

        <!-- 登录按钮 -->
        <el-button type="primary" size="large" class="w-full !py-3 !text-lg !rounded-xl !font-semibold mt-6" @click="handleLogin">
          登录 / 注册
        </el-button>
        
        <div class="text-center mt-4">
          <span @click="router.push('/register')" class="text-sm text-sky-200 cursor-pointer hover:text-white transition">
            没有账号？去注册
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-bg {
  background-image: linear-gradient(rgba(6,16,38,.35), rgba(6,16,38,.55)), url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80');
  background-size: cover; background-position: center;
}
:deep(.el-input__wrapper) { background-color: rgba(255, 255, 255, 0.15) !important; box-shadow: none !important; border: 1px solid rgba(255, 255, 255, 0.3) !important; }
:deep(.el-input__inner) { color: #fff !important; }
</style>