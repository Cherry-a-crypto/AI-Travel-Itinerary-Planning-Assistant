<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore() 

const username = ref('')
const password = ref('')
const isLoading = ref(false)

const handleLogin = async () => {
  if (!username.value || !password.value) {
    ElMessage.warning('请输入账号和密码')
    return
  }

  isLoading.value = true
  try {
    const res = await request.post('/api/users/login', {
      username: username.value,
      passwordHash: password.value
    })
    
    if (res.code === 200) {
      // 1. 提取双 Token
      const { accessToken, refreshToken, userInfo } = res.data
      
      // 2. 存入 Pinia
      userStore.login(accessToken, refreshToken, userInfo) 
      
      ElMessage.success('登录成功！')

      // 3. 打印测试日志（F12 可以看）
      console.log("准备跳转，当前存下的 Token:", localStorage.getItem('accessToken'))
      
      // 4. 标准路由跳转（千万别用 window.location.href）
      router.push('/home')
      
    } else {
      ElMessage.error(res.message || '登录失败')
    } 
  } catch (error) {
    console.error('请求失败:', error)
    ElMessage.error(error.response?.data?.message || '网络异常，请检查后端服务')
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="login-bg min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/90 shadow-xl mb-4 text-3xl">✈️</div>
        <h1 class="text-3xl font-bold text-white tracking-wide drop-shadow-lg">AI旅行行程规划助手</h1>
      </div>

      <div class="bg-white/10 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl p-8">
        <div class="space-y-4">
          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">账号</label>
            <el-input v-model="username" placeholder="请输入手机号 / 邮箱" size="large" />
          </div>

          <div>
            <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">密码</label>
            <el-input v-model="password" type="password" placeholder="请输入密码" size="large" show-password />
          </div>
        </div>

        <el-button type="primary" size="large" class="w-full !py-3 !text-lg !rounded-xl !font-semibold mt-6" :loading="isLoading" @click="handleLogin">
          登录 / 注册
        </el-button>
        
        <div class="text-center mt-4">
          <span @click="router.push('/register')" class="text-sm text-sky-200 cursor-pointer hover:text-white transition">
            没有账号？去注册
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-bg {
  background-image: linear-gradient(rgba(6,16,38,.35), rgba(6,16,38,.55)), url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80');
  background-size: cover; background-position: center;
}
:deep(.el-input__wrapper) { background-color: rgba(255, 255, 255, 0.15) !important; box-shadow: none !important; border: 1px solid rgba(255, 255, 255, 0.3) !important; }
:deep(.el-input__inner) { color: #fff !important; }
</style>