<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()

// 企业级规范：添加加载状态，避免页面白屏闪烁
const isLoading = ref(true)

// 1. 动态景点数据
const pois = ref([])

// 2. 获取后端真实数据
const fetchPois = async () => {
  isLoading.value = true
  try {
    // 请求你的后端分页接口
    const res = await request.get('/api/pois/page?page=1&size=3')
    
    if (res.code === 200) {
      // MyBatis-Plus 分页数据在 records 中
      pois.value = res.data.records || []
      console.log('【企业级日志】成功拉取景点数据:', pois.value)
    } else {
      ElMessage.error(res.message || '获取景点列表失败')
    }
  } catch (error) {
    console.error('【异常拦截】网络请求失败:', error)
    ElMessage.error('网络异常，请检查后端服务')
  } finally {
    isLoading.value = false
  }
}

// 3. 生成行程（保留你的逻辑）
const generateTrip = async () => {
  try {
    const res = await request.post('/api/trips/create', {
      title: '我的北京之旅',
      destination: '北京',
      startDate: '2026-11-01',
      endDate: '2026-11-03',
      budget: 2000.00
    })
    if (res.code === 200) {
      ElMessage.success('AI行程创建成功！')
      sessionStorage.setItem('aiText', res.data.aiText)
      router.push(`/detail?id=${res.data.trip.id}`)
    }
  } catch (error) {
    ElMessage.error('创建行程失败')
  }
}

// 4. 评论区数据（保留你的原样）
const comments = ref([
  { id: 1, name: '雪山飞狐', time: '2 小时前 · 北京', content: 'AI 排的故宫行程太省心了！避开了人流高峰，还推荐了角楼咖啡，拍照绝了📸', avatar: '雪', color: 'from-sky-400 to-blue-500' },
  { id: 2, name: '风之旅人', time: '昨天 · 上海', content: '长城那天预报有雨，AI 自动把行程调到了上午，下午果然下雨了，神预测！', avatar: '风', color: 'from-emerald-400 to-teal-500' },
  { id: 3, name: '桃桃乌龙', time: '3 天前 · 广州', content: '颐和园傍晚的昆明湖美到失语，跟着 AI 推荐的路线走，一步冤枉路都没多走。', avatar: '桃', color: 'from-amber-400 to-orange-500' }
])

const addComment = () => {
  const text = prompt('分享你的旅行体验：')
  if (!text) return
  comments.value.unshift({
    id: Date.now(), name: '我', time: '刚刚 · 北京', content: text, avatar: '我', color: 'from-sky-400 to-blue-500'
  })
}

// 5. 页面挂载时拉取数据
onMounted(() => {
  fetchPois()
})
</script>

<template>
  <!-- 恢复你最喜欢的经典浅色渐变背景 -->
  <div class="min-h-screen bg-gradient-to-b from-sky-50 via-white to-sky-50/50">
    
    <!-- 顶部导航栏 -->
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-6">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold bg-gradient-to-r from-sky-600 to-blue-500 bg-clip-text text-transparent">AI旅行行程规划助手</span>
        </div>
        <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">首页</a>
          <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">发现</a>
          <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">我的</a>
        </div>
        <button @click="router.push('/')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white hover:border-sky-500 transition">退出登录</button>
      </div>
    </nav>

    <!-- Hero 区 -->
    <section class="relative overflow-hidden max-w-6xl mx-auto px-6 pt-20 pb-14 text-center">
      <span class="inline-block px-4 py-1.5 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold tracking-wide mb-5">🤖 AI POWERED TRIP PLANNER</span>
      <h2 class="text-5xl font-extrabold text-slate-800 leading-tight mb-4">下一站，让 <span class="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">AI</span> 帮你安排</h2>
      <p class="text-slate-500 max-w-xl mx-auto mb-10">告诉我你的目的地与偏好，10 秒生成吃住行全包的专属旅行行程</p>
      <button @click="generateTrip" class="group px-12 py-4 rounded-full bg-gradient-to-r from-sky-500 to-blue-500 text-white text-lg font-semibold shadow-xl shadow-sky-300/50 hover:shadow-2xl hover:shadow-sky-400/50 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200">
        ✨ 生成我的专属行程
        <span class="inline-block ml-1 group-hover:translate-x-1 transition-transform">→</span>
      </button>
    </section>

    <!-- 热门景点动态渲染区 -->
    <section class="max-w-6xl mx-auto px-6 pb-16">
      <div class="flex items-end justify-between mb-6">
        <div>
          <h3 class="text-2xl font-bold text-slate-800">热门推荐 · 北京</h3>
          <p class="text-sm text-slate-400 mt-1">真实旅行者的最爱目的地</p>
        </div>
        <a href="#" class="text-sm text-sky-600 hover:text-sky-500 font-medium">查看全部 →</a>
      </div>
      
      <!-- 加载中骨架屏（企业级体验） -->
      <div v-if="isLoading" class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="i in 3" :key="i" class="bg-white rounded-2xl h-80 animate-pulse border border-sky-50 shadow-sm"></div>
      </div>

      <!-- 动态数据渲染 -->
      <div v-else class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="poi in pois" :key="poi.id" class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 border border-sky-50">
          <div class="relative h-52 overflow-hidden">
            <!-- 动态图片匹配逻辑 -->
            <img 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              :src="poi.name.includes('故宫') ? '/gugong.jpg' : (poi.name.includes('长城') ? '/changcheng.jpg' : '/yiheyuan.jpg')" 
              :alt="poi.name">
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur text-white text-xs">
              🏛️ {{ poi.category || '景点' }}
            </span>
          </div>
          <div class="p-5">
            <div class="flex items-center justify-between mb-1.5">
              <h4 class="text-lg font-bold text-slate-800">{{ poi.name }}</h4>
              <span class="flex items-center gap-1 text-amber-500 text-sm font-semibold">★ 4.9</span>
            </div>
            <p class="text-sm text-slate-500 leading-relaxed line-clamp-2">
              📍 {{ poi.address || '北京市' }} <br>
              ⏰ {{ poi.openTime || '全天开放' }}
            </p>
            <div class="mt-4 flex items-center justify-between text-sm">
              <span class="text-sky-600 font-bold">¥{{ poi.ticketPrice || '免费' }} <span class="text-xs font-normal text-slate-400">起</span></span>
              <span class="text-xs text-slate-400">2.3万条评价</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 空状态兜底（企业级规范） -->
      <div v-if="!isLoading && pois.length === 0" class="text-center py-20 bg-white rounded-2xl border border-sky-50">
        <p class="text-slate-400">暂无景点数据，请检查后端数据库是否有数据。</p>
      </div>
    </section>

    <!-- 社区评论区 -->
    <section class="max-w-6xl mx-auto px-6 pb-20">
      <div class="flex items-end justify-between mb-6">
        <h3 class="text-2xl font-bold text-slate-800">旅行者说</h3>
        <button @click="addComment" class="text-sm px-4 py-2 rounded-full bg-sky-500 text-white hover:bg-sky-400 transition font-medium">✏️ 写评论</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div v-for="c in comments" :key="c.id" class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
          <div class="flex items-center gap-3 mb-3">
            <span :class="`w-10 h-10 rounded-full bg-gradient-to-br ${c.color} flex items-center justify-center text-white font-bold`">{{ c.avatar }}</span>
            <div>
              <p class="font-semibold text-slate-800 text-sm">{{ c.name }}</p>
              <p class="text-xs text-slate-400">{{ c.time }}</p>
            </div>
            <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
          </div>
          <p class="text-sm text-slate-600 leading-relaxed">{{ c.content }}</p>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
</style>