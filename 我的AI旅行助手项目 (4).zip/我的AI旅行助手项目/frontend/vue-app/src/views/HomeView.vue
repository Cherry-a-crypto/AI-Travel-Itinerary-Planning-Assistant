<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '../utils/request'
import { ElMessage } from 'element-plus'

const router = useRouter()

// 企业级规范：添加加载状态
const isLoading = ref(true)

// 1. 动态景点数据
const pois = ref([])

// 👇 新增：定义一个表示是否正在生成的锁
const isGenerating = ref(false) 

// 👇 新增：绑定输入框的自然语言变量
const userIntent = ref('我想去北京玩三天，预算两千')

// 2. 获取后端真实数据
const fetchPois = async () => {
  isLoading.value = true
  try {
    const res = await request.get('/api/pois/page?page=1&size=3')
    if (res.code === 200) {
      pois.value = res.data.records || []
    } else {
      ElMessage.error(res.message || '获取景点列表失败')
    }
  } catch (error) {
    console.error('网络请求失败:', error)
  } finally {
    isLoading.value = false
  }
}

// 3. 生成行程（核心改变：调用意图解析接口）
const generateTrip = async () => {
  if (!userIntent.value.trim()) {
    ElMessage.warning('请输入您的旅行需求哦')
    return
  }

  // 👇 核心：如果这把锁是 true（正在生成中），直接 return，拦截你的疯狂点击
  if (isGenerating.value) return

  isGenerating.value = true // 👈 上锁：请求开始前锁死

  try {
    const res = await request.post('/api/trips/generate-by-intent', {
      intent: userIntent.value
    })
    
    if (res.code === 200) {
      ElMessage.success(`AI已解析出您要去【${res.data.trip.destination}】，行程生成成功！`)
      router.push(`/detail?id=${res.data.trip.id}`)
    } else {
      ElMessage.error(res.message)
    }
  } catch (error) {
    ElMessage.error('创建行程失败')
  } finally {
    // 👇 核心：不管成功还是失败，最后都要把锁解开，让用户能点下一次
    isGenerating.value = false 
  }
}

// 4. 评论区数据
const comments = ref([
  { id: 1, name: '雪山飞狐', time: '2 小时前 · 北京', content: 'AI 排的故宫行程太省心了！避开了人流高峰，还推荐了角楼咖啡，拍照绝了📸', avatar: '雪', color: 'from-sky-400 to-blue-500' },
  { id: 2, name: '风之旅人', time: '昨天 · 上海', content: '长城那天预报有雨，AI 自动把行程调到了上午，下午果然下雨了，神预测！', avatar: '风', color: 'from-emerald-400 to-teal-500' },
  { id: 3, name: '桃桃乌龙', time: '3 天前 · 广州', content: '颐和园傍晚的昆明湖美到失语，跟着 AI 推荐的路线走，一步冤枉路都没多走。', avatar: '桃', color: 'from-amber-400 to-orange-500' }
])

const addComment = () => {
  const text = prompt('分享你的旅行体验：')
  if (!text) return
  comments.value.unshift({
    id: Date.now(), name: '我', time: '刚刚 · 北京', content: text, avatar: '我', color: 'from-sky-400 to-blue-500'
  })
}

// 5. 页面挂载时拉取数据
onMounted(() => {
  fetchPois()
})
</script>

<template>
  <div class="min-h-screen bg-gradient-to-b from-sky-50 via-white to-sky-50/50">
    
    <!-- 顶部导航栏 -->
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-6">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold bg-gradient-to-r from-sky-600 to-blue-500 bg-clip-text text-transparent">AI旅行行程规划助手</span>
        </div>
                <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <!-- 首页保持原样 -->
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">首页</a>
          <!-- 发现：加上点击跳转 -->
          <span @click="router.push('/discover')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">发现</span>
          <!-- 我的：加上点击跳转 -->
          <span @click="router.push('/mine')" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 cursor-pointer transition">我的</span>
          <el-button type="primary" text @click="router.push('/prep/1')">
    🎒 行前准备
  </el-button>
        </div>
        <button @click="router.push('/')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white hover:border-sky-500 transition">退出登录</button>
      </div>
    </nav>

    <!-- Hero 区 -->
    <section class="relative overflow-hidden max-w-6xl mx-auto px-6 pt-20 pb-14 text-center">
      <span class="inline-block px-4 py-1.5 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold tracking-wide mb-5">🤖 AI POWERED TRIP PLANNER</span>
      <h2 class="text-5xl font-extrabold text-slate-800 leading-tight mb-4">下一站，让 <span class="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">AI</span> 帮你安排</h2>
      <p class="text-slate-500 max-w-xl mx-auto mb-8">告诉我你的目的地与偏好，10 秒生成吃住行全包的专属旅行行程</p>
      
      <!-- 👇 新增：自然语言输入框 -->
      <div class="max-w-2xl mx-auto mb-8 relative group">
        <div class="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <span class="text-xl">💬</span>
        </div>
        <input 
          v-model="userIntent" 
          type="text" 
          placeholder="例如：我想去上海玩2天，喜欢美食，预算3000..."
          class="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-sky-100 outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 bg-white text-slate-700 shadow-lg transition-all duration-300 text-lg"
        />
      </div>

      <button 
  @click="generateTrip" 
  :disabled="isGenerating"
  class="group px-12 py-4 rounded-full bg-gradient-to-r from-sky-500 to-blue-500 text-white text-lg font-semibold shadow-xl shadow-sky-300/50 hover:shadow-2xl hover:shadow-sky-400/50 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
>
  <!-- 动态显示文字 -->
  {{ isGenerating ? '⏳ AI 正在为您规划中...' : '✨ 生成我的专属行程' }}
  <span v-if="!isGenerating" class="inline-block ml-1 group-hover:translate-x-1 transition-transform">→</span>
</button>
    </section>

    <!-- 热门景点动态渲染区 -->
    <section class="max-w-6xl mx-auto px-6 pb-16">
      <div class="flex items-end justify-between mb-6">
        <div>
          <h3 class="text-2xl font-bold text-slate-800">热门推荐 · 北京</h3>
          <p class="text-sm text-slate-400 mt-1">真实旅行者的最爱目的地</p>
        </div>
        <a href="#" class="text-sm text-sky-600 hover:text-sky-500 font-medium">查看全部 →</a>
      </div>
      
      <!-- 加载中骨架屏 -->
      <div v-if="isLoading" class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="i in 3" :key="i" class="bg-white rounded-2xl h-80 animate-pulse border border-sky-50 shadow-sm"></div>
      </div>

      <!-- 动态数据渲染 -->
      <div v-else class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="poi in pois" :key="poi.id" class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 border border-sky-50">
          <div class="relative h-52 overflow-hidden">
            <!-- 动态图片匹配逻辑 -->
            <img 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              :src="poi.name.includes('故宫') ? '/gugong.jpg' : (poi.name.includes('长城') ? '/changcheng.jpg' : '/yiheyuan.jpg')" 
              :alt="poi.name">
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur text-white text-xs">
              🏛️ {{ poi.category || '景点' }}
            </span>
          </div>
          <div class="p-5">
            <div class="flex items-center justify-between mb-1.5">
              <h4 class="text-lg font-bold text-slate-800">{{ poi.name }}</h4>
              <span class="flex items-center gap-1 text-amber-500 text-sm font-semibold">★ 4.9</span>
            </div>
            <p class="text-sm text-slate-500 leading-relaxed line-clamp-2">
              📍 {{ poi.address || '北京市' }} <br>
              ⏰ {{ poi.openTime || '全天开放' }}
            </p>
            <div class="mt-4 flex items-center justify-between text-sm">
              <span class="text-sky-600 font-bold">¥{{ poi.ticketPrice || '免费' }} <span class="text-xs font-normal text-slate-400">起</span></span>
              <span class="text-xs text-slate-400">2.3万条评价</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 空状态兜底 -->
      <div v-if="!isLoading && pois.length === 0" class="text-center py-20 bg-white rounded-2xl border border-sky-50">
        <p class="text-slate-400">暂无景点数据，请检查后端数据库是否有数据。</p>
      </div>
    </section>

    <!-- 社区评论区 -->
    <section class="max-w-6xl mx-auto px-6 pb-20">
      <div class="flex items-end justify-between mb-6">
        <h3 class="text-2xl font-bold text-slate-800">旅行者说</h3>
        <button @click="addComment" class="text-sm px-4 py-2 rounded-full bg-sky-500 text-white hover:bg-sky-400 transition font-medium">✏️ 写评论</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div v-for="c in comments" :key="c.id" class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
          <div class="flex items-center gap-3 mb-3">
            <span :class="`w-10 h-10 rounded-full bg-gradient-to-br ${c.color} flex items-center justify-center text-white font-bold`">{{ c.avatar }}</span>
            <div>
              <p class="font-semibold text-slate-800 text-sm">{{ c.name }}</p>
              <p class="text-xs text-slate-400">{{ c.time }}</p>
            </div>
            <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
          </div>
          <p class="text-sm text-slate-600 leading-relaxed">{{ c.content }}</p>
        </div>
      </div>
    </section>
  </div>
   
      <el-button type="success" size="large" @click="router.push('/prep/1')">
        🎒 去行前准备舱
      </el-button>
</template>

<style scoped>
</style>
