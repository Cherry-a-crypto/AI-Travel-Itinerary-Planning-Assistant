<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// 响应式评论区（原版的3条数据）
const comments = ref([
  { id: 1, name: '雪山飞狐', time: '2 小时前 · 北京', content: 'AI 排的故宫行程太省心了！避开了人流高峰，还推荐了角楼咖啡，拍照绝了📸', avatar: '雪', color: 'from-sky-400 to-blue-500' },
  { id: 2, name: '风之旅人', time: '昨天 · 上海', content: '长城那天预报有雨，AI 自动把行程调到了上午，下午果然下雨了，神预测！', avatar: '风', color: 'from-emerald-400 to-teal-500' },
  { id: 3, name: '桃桃乌龙', time: '3 天前 · 广州', content: '颐和园傍晚的昆明湖美到失语，跟着 AI 推荐的路线走，一步冤枉路都没多走。', avatar: '桃', color: 'from-amber-400 to-orange-500' }
])

const addComment = () => {
  const text = prompt('分享你的旅行体验：')
  if (!text) return
  comments.value.unshift({
    id: Date.now(), name: '我', time: '刚刚 · 北京', content: text, avatar: '我', color: 'from-sky-400 to-blue-500'
  })
}
</script>

<template>
  <div class="min-h-screen bg-gradient-to-b from-sky-50 via-white to-sky-50/50">
    <!-- 顶部导航栏 -->
    <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-6">
        <div class="flex items-center gap-2 shrink-0">
          <span class="text-2xl">✈️</span>
          <span class="text-lg font-bold bg-gradient-to-r from-sky-600 to-blue-500 bg-clip-text text-transparent">AI旅行行程规划助手</span>
        </div>
        <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
          <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">首页</a>
          <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">发现</a>
          <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">我的</a>
        </div>
        <button @click="router.push('/')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white hover:border-sky-500 transition">退出登录</button>
      </div>
    </nav>

    <!-- Hero 区 -->
    <section class="relative overflow-hidden max-w-6xl mx-auto px-6 pt-20 pb-14 text-center">
      <span class="inline-block px-4 py-1.5 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold tracking-wide mb-5">🤖 AI POWERED TRIP PLANNER</span>
      <h2 class="text-5xl font-extrabold text-slate-800 leading-tight mb-4">下一站，让 <span class="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">AI</span> 帮你安排</h2>
      <p class="text-slate-500 max-w-xl mx-auto mb-10">告诉我你的目的地与偏好，10 秒生成吃住行全包的专属旅行行程</p>
      <button @click="router.push('/detail')"
        class="group px-12 py-4 rounded-full bg-gradient-to-r from-sky-500 to-blue-500 text-white text-lg font-semibold shadow-xl shadow-sky-300/50 hover:shadow-2xl hover:shadow-sky-400/50 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200">
        ✨ 生成我的专属行程 <span class="inline-block ml-1 group-hover:translate-x-1 transition-transform">→</span>
      </button>
    </section>

    <!-- 热门景点三列卡片 -->
    
    <!-- 热门景点三列卡片 -->
    <section class="max-w-6xl mx-auto px-6 pb-16">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <!-- 故宫 -->
        <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer border border-sky-50">
          <div class="relative h-52 overflow-hidden">
            <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="/gugong.jpg" alt="故宫">
          </div>
          <div class="p-5">
            <h4 class="text-lg font-bold text-slate-800 mb-2">故宫博物院</h4>
            <p class="text-sm text-slate-500 leading-relaxed">明清皇家宫殿，世界现存最大木质古建筑群，六百年的皇城记忆。</p>
            <div class="mt-4 flex items-center justify-between text-sm">
              <span class="text-sky-600 font-bold">¥60 <span class="text-xs font-normal text-slate-400">起</span></span>
              <span class="flex items-center gap-1 text-amber-500 font-semibold">★ 4.9</span>
            </div>
          </div>
        </div>

        <!-- 长城 -->
        <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer border border-sky-50">
          <div class="relative h-52 overflow-hidden">
            <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="/changcheng.jpg" alt="长城">
          </div>
          <div class="p-5">
            <h4 class="text-lg font-bold text-slate-800 mb-2">八达岭长城</h4>
            <p class="text-sm text-slate-500 leading-relaxed">不到长城非好汉，登高远眺，感受千年历史的雄伟壮阔。</p>
            <div class="mt-4 flex items-center justify-between text-sm">
              <span class="text-sky-600 font-bold">¥40 <span class="text-xs font-normal text-slate-400">起</span></span>
              <span class="flex items-center gap-1 text-amber-500 font-semibold">★ 4.8</span>
            </div>
          </div>
        </div>

        <!-- 颐和园 -->
        <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer border border-sky-50">
          <div class="relative h-52 overflow-hidden">
            <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="/yiheyuan.jpg" alt="颐和园">
          </div>
          <div class="p-5">
            <h4 class="text-lg font-bold text-slate-800 mb-2">颐和园</h4>
            <p class="text-sm text-slate-500 leading-relaxed">保存最完整的皇家园林，昆明湖与万寿山相映成趣，四季皆景。</p>
            <div class="mt-4 flex items-center justify-between text-sm">
              <span class="text-sky-600 font-bold">¥30 <span class="text-xs font-normal text-slate-400">起</span></span>
              <span class="flex items-center gap-1 text-amber-500 font-semibold">★ 4.8</span>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- 社区评论区 -->
    <section class="max-w-6xl mx-auto px-6 pb-20">
      <div class="flex items-end justify-between mb-6">
        <h3 class="text-2xl font-bold text-slate-800">旅行者说</h3>
        <button @click="addComment" class="text-sm px-4 py-2 rounded-full bg-sky-500 text-white hover:bg-sky-400 transition font-medium">✏️ 写评论</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div v-for="c in comments" :key="c.id" class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
          <div class="flex items-center gap-3 mb-3">
            <span :class="`w-10 h-10 rounded-full bg-gradient-to-br ${c.color} flex items-center justify-center text-white font-bold`">{{ c.avatar }}</span>
            <div>
              <p class="font-semibold text-slate-800 text-sm">{{ c.name }}</p>
              <p class="text-xs text-slate-400">{{ c.time }}</p>
            </div>
            <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
          </div>
          <p class="text-sm text-slate-600 leading-relaxed">{{ c.content }}</p>
        </div>
      </div>
    </section>
  </div>
</template>