<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '../utils/request'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'

const route = useRoute()
const tripId = route.params.tripId || 1 // 默认给个 1 防止报错

// --- 行李清单逻辑 ---
const packingList = ref([])
const newItemName = ref('')

const fetchPackingList = async () => {
  try {
    const res = await request.get(`/api/prep/packing/${tripId}`)
    if (res.code === 200) {
      packingList.value = res.data
    }
  } catch (error) {
    console.error("获取清单失败", error)
  }
}

const addPackingItem = () => {
  if (!newItemName.value.trim()) return
  packingList.value.push({
    id: Date.now(),
    itemName: newItemName.value,
    category: '其他',
    isChecked: false
  })
  newItemName.value = ''
  ElMessage.success('已添加到清单')
}

// --- 预算统计与 ECharts 逻辑 ---
const chartRef = ref(null)
let myChart = null

const initChart = async () => {
  try {
    const res = await request.get(`/api/prep/expense/${tripId}`)
    let data = []
    if (res.code === 200) {
      data = res.data
    }

    const chartData = data.map(item => ({ name: item.category, value: item.amount }))
    const totalAmount = chartData.reduce((sum, item) => sum + item.value, 0)

    if (myChart) myChart.dispose()
    myChart = echarts.init(chartRef.value)
    
    const option = {
      title: {
        text: `总计: ¥${totalAmount.toFixed(2)}`,
        left: 'center',
        top: '5%',
        textStyle: { color: '#333', fontSize: 16, fontWeight: 'bold' }
      },
      tooltip: { trigger: 'item' },
      legend: { bottom: '5%', left: 'center' },
      series: [
        {
          name: '花费',
          type: 'pie',
          radius: ['45%', '70%'], // 环形图效果
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 8,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: { show: false },
          data: chartData,
          color: ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de']
        }
      ]
    }
    myChart.setOption(option)
  } catch (error) {
    console.error("获取预算失败", error)
  }
}

// 监听窗口大小改变，让图表自适应
const handleResize = () => {
  if (myChart) myChart.resize()
}

onMounted(() => {
  fetchPackingList()
  initChart()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  if (myChart) myChart.dispose()
})
</script>

<template>
  <div class="prep-container">
    <div class="header">
      <h2>🎒 行前准备舱</h2>
      <p>出行前的细致准备，是完美旅程的一半</p>
    </div>

    <div class="content-layout">
      <!-- 左侧：行李清单 -->
      <el-card class="box-card list-card" shadow="hover">
        <template #header>
          <div class="card-header">
            <span>🧳 AI 智能行李清单</span>
          </div>
        </template>

        <div class="add-item">
          <el-input 
            v-model="newItemName" 
            placeholder="添加自定义物品 (按回车或点击添加)" 
            @keyup.enter="addPackingItem"
            clearable
          />
          <el-button type="primary" @click="addPackingItem">添加</el-button>
        </div>

        <div class="packing-list">
          <el-empty v-if="packingList.length === 0" description="清单为空" />
          <div 
            v-for="item in packingList" 
            :key="item.id" 
            class="packing-item"
            :class="{ 'is-checked': item.isChecked }"
          >
            <el-checkbox v-model="item.isChecked" size="large">
              <span class="item-name">{{ item.itemName }}</span>
              <el-tag size="small" type="info" style="margin-left: 10px">{{ item.category }}</el-tag>
            </el-checkbox>
          </div>
        </div>
      </el-card>

      <!-- 右侧：预算管家 -->
      <el-card class="box-card budget-card" shadow="hover">
        <template #header>
          <div class="card-header">
            <span>💰 预算统计图表</span>
            <el-button type="success" size="small" plain>+ 记一笔</el-button>
          </div>
        </template>
        <div class="chart-wrapper" ref="chartRef"></div>
      </el-card>
    </div>
  </div>
</template>

<style scoped>
.prep-container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 30px 20px;
  min-height: 100vh;
  background-color: #f7f9fc;
}
.header {
  text-align: center;
  margin-bottom: 40px;
}
.header h2 {
  font-size: 28px;
  color: #2c3e50;
  margin-bottom: 10px;
}
.header p {
  color: #7f8c8d;
}
.content-layout {
  display: flex;
  gap: 24px;
}
.list-card {
  flex: 1.2;
  border-radius: 12px;
  border: none;
}
.budget-card {
  flex: 1;
  border-radius: 12px;
  border: none;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: bold;
  font-size: 16px;
  color: #34495e;
}
.add-item {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}
.packing-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.packing-item {
  padding: 14px;
  background-color: #fff;
  border: 1px solid #ecf0f1;
  border-radius: 8px;
  transition: all 0.3s;
}
.packing-item:hover {
  border-color: #3498db;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.is-checked .item-name {
  text-decoration: line-through;
  color: #bdc3c7;
}
.chart-wrapper {
  width: 100%;
  height: 350px;
}
</style>