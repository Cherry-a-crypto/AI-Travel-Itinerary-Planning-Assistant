import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'login',
      component: LoginView
    },
    {
      path: '/home',
      name: 'home',
      component: () => import('../views/HomeView.vue')
    },
    {
      path: '/detail',
      name: 'detail',
      component: () => import('../views/DetailView.vue')
    },
    {
      path: '/register',
      name: 'register',
      component: () => import('../views/RegisterView.vue')
    },
    {
      path: '/poi-list',
      name: 'poiList',
      component: () => import('../views/PoiListView.vue')
    },
    {
      path: '/discover',
      name: 'discover',
      component: () => import('../views/DiscoverView.vue')
    },
    {
      path: '/mine',
      name: 'mine',
      component: () => import('../views/MineView.vue')
    },
        {
      path: '/prep/:tripId',
      name: 'prep',
      component: () => import('../views/PrepView.vue')
    }
  ]
})

// 路由守卫：拦截未登录的访问
router.beforeEach((to, from, next) => {
  // 👇 核心修改：这里必须检查 accessToken
  const token = localStorage.getItem('accessToken')
  
  // 如果要去除登录/注册以外的页面，且没有 Token，就踢回登录页
  if (to.path !== '/' && to.path !== '/register' && !token)  {
    next('/')
  } else {
    next()
  }
})

export default router