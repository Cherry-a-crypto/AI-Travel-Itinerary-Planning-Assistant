import {createRouter,createWebHistory} from 'vue-router'
import LoginView from '../views/LoginView.vue'

const router =createRouter({
    history:createWebHistory(),
    routes:[
        {
            path:'/',
            name:'login',
            component:LoginView
        },
        {
            path:'/home',
            name:'home',
            component:()=>import('../views/HomeView.vue')
        },
        {
            path:'/detail',
            name:'detail',
            component:()=>import('../views/DetailView.vue')
        }
    ]
})
export default router
// 路由守卫：拦截未登录的访问
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  
  // 如果要去首页或详情页，但没有 Token，就强制踢回登录页
  if (to.path !== '/' && !token) {
    next('/')
  } else {
    next()
  }
})