<script setup>
// ===== 简易路由：三页互相跳转 =====
function go(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  window.scrollTo(0, 0);
}

// ===== 手风琴：折叠 / 展开 =====
function toggleDay(n) {
  const body = document.getElementById('day-' + n);
  const arrow = document.getElementById('arrow-' + n);
  const open = body.style.maxHeight !== '0px';
  body.style.maxHeight = open ? '0px' : '500px';
  arrow.classList.toggle('rotate-180', !open);
}

// ===== 重新生成：按钮 loading + 随机换 AI 提示 =====
function regenerate(event) {
  const btn = event.currentTarget; // Vue 中获取点击的按钮
  const old = btn.innerHTML;
  btn.innerHTML = '⏳ AI 规划中…';
  btn.disabled = true;
  setTimeout(() => {
    const tips = [
      '今日小雨转阴 18~23°C，AI已调整<strong>室内景点优先</strong>',
      '明日转晴 16~26°C，AI已将长城行程调整至<strong>上午出发</strong>',
      '空气质量优，AI已为你加入<strong>景山日落观景</strong>环节'
    ];
    document.getElementById('weather-tip').innerHTML = tips[Math.floor(Math.random() * tips.length)];
    btn.innerHTML = old;
    btn.disabled = false;
  }, 800);
}

// ===== 写评论：简单追加到评论区最前 =====
function addComment() {
  const text = prompt('分享你的旅行体验：');
  if (!text) return;
  const list = document.getElementById('comment-list');
  const div = document.createElement('div');
  div.className = 'bg-white rounded-2xl p-5 shadow-sm border border-sky-100 hover:shadow-md transition';
  div.innerHTML = `
    <div class="flex items-center gap-3 mb-3">
      <span class="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-blue-500 flex items-center justify-center text-white font-bold">我</span>
      <div>
        <p class="font-semibold text-slate-800 text-sm">我</p>
        <p class="text-xs text-slate-400">刚刚 · 北京</p>
      </div>
      <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
    </div>
    <p class="text-sm text-slate-600 leading-relaxed"></p>`;
  div.querySelector('p:last-child').textContent = text;
  list.prepend(div);
}
</script>

<template>
  <div class="bg-white text-slate-800 antialiased">
    <!-- 页面 1：登录页 -->
    <div id="page-login" class="page active">
      <div class="login-bg min-h-screen flex items-center justify-center px-4">
        <div class="w-full max-w-md">
          <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/90 shadow-xl shadow-sky-900/40 mb-4 text-3xl">✈️</div>
            <h1 class="text-3xl font-bold text-white tracking-wide drop-shadow-lg">AI旅行行程规划助手</h1>
            <p class="text-sky-200/90 text-sm mt-2">智能规划 · 随心出行</p>
          </div>
          <div class="bg-white/10 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl p-8">
            <div class="space-y-4">
              <div>
                <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">账号</label>
                <input type="text" placeholder="请输入手机号 / 邮箱" class="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-sky-100/60 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:bg-white/30 transition">
              </div>
              <div>
                <label class="block text-xs text-sky-100/80 mb-1.5 ml-1">密码</label>
                <input type="password" placeholder="请输入密码" class="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-sky-100/60 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:bg-white/30 transition">
              </div>
              <button @click="go('home')" class="w-full py-3.5 rounded-xl bg-sky-400 text-white font-semibold text-lg shadow-lg shadow-sky-900/40 hover:bg-sky-300 hover:shadow-sky-500/30 hover:-translate-y-0.5 active:translate-y-0 active:bg-sky-500 transition-all duration-200">
                登录 / 注册
              </button>
              <div class="flex items-center justify-between text-xs text-sky-100/70 pt-1">
                <label class="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" checked class="accent-sky-400">记住我</label>
                <a href="#" class="hover:text-white transition">忘记密码？</a>
              </div>
            </div>
          </div>
          <p class="text-center text-sky-100/50 text-xs mt-6">登录即代表同意《用户协议》与《隐私政策》</p>
        </div>
      </div>
    </div>

    <!-- 页面 2：首页 -->
    <div id="page-home" class="page">
      <div class="min-h-screen bg-gradient-to-b from-sky-50 via-white to-sky-50/50">
        <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
          <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-6">
            <div class="flex items-center gap-2 shrink-0">
              <span class="text-2xl">✈️</span>
              <span class="text-lg font-bold bg-gradient-to-r from-sky-600 to-blue-500 bg-clip-text text-transparent">AI旅行行程规划助手</span>
            </div>
            <div class="flex items-center gap-1 text-sm font-medium text-slate-600">
              <a href="#" class="px-4 py-2 rounded-full text-sky-600 bg-sky-100/70">首页</a>
              <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">发现</a>
              <a href="#" class="px-4 py-2 rounded-full hover:bg-sky-50 hover:text-sky-600 transition">我的</a>
            </div>
            <div class="hidden md:flex items-center flex-1 max-w-xs">
              <div class="w-full flex items-center bg-sky-50 border border-sky-200 rounded-full px-4 py-2 focus-within:ring-2 focus-within:ring-sky-300 transition">
                <svg class="w-4 h-4 text-slate-400 mr-2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.3-4.3"/></svg>
                <input type="text" placeholder="搜索目的地 / 景点" class="w-full bg-transparent text-sm focus:outline-none placeholder-slate-400">
              </div>
            </div>
            <button @click="go('login')" class="shrink-0 text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-500 hover:text-white hover:border-sky-500 transition">退出登录</button>
          </div>
        </nav>

        <section class="relative overflow-hidden">
          <div class="absolute -top-24 -right-24 w-96 h-96 bg-sky-200/40 rounded-full blur-3xl"></div>
          <div class="absolute -bottom-32 -left-24 w-96 h-96 bg-blue-200/30 rounded-full blur-3xl"></div>
          <div class="relative max-w-6xl mx-auto px-6 pt-20 pb-14 text-center">
            <span class="inline-block px-4 py-1.5 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold tracking-wide mb-5">🤖 AI POWERED TRIP PLANNER</span>
            <h2 class="text-5xl font-extrabold text-slate-800 leading-tight mb-4">下一站，让 <span class="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">AI</span> 帮你安排</h2>
            <p class="text-slate-500 max-w-xl mx-auto mb-10">告诉我你的目的地与偏好，10 秒生成吃住行全包的专属旅行行程</p>
            <button @click="go('detail')" class="group px-12 py-4 rounded-full bg-gradient-to-r from-sky-500 to-blue-500 text-white text-lg font-semibold shadow-xl shadow-sky-300/50 hover:shadow-2xl hover:shadow-sky-400/50 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200">
              ✨ 生成我的专属行程 <span class="inline-block ml-1 group-hover:translate-x-1 transition-transform">→</span>
            </button>
            <div class="mt-10 flex items-center justify-center gap-8 text-sm text-slate-400">
              <span><strong class="text-slate-700">1200万+</strong> 已生成行程</span>
              <span class="w-px h-4 bg-slate-200"></span>
              <span><strong class="text-slate-700">200+</strong> 覆盖城市</span>
              <span class="w-px h-4 bg-slate-200"></span>
              <span><strong class="text-slate-700">4.9</strong> 用户评分</span>
            </div>
          </div>
        </section>

        <section class="max-w-6xl mx-auto px-6 pb-16">
          <div class="flex items-end justify-between mb-6">
            <div>
              <h3 class="text-2xl font-bold text-slate-800">热门推荐 · 北京</h3>
              <p class="text-sm text-slate-400 mt-1">真实旅行者的最爱目的地</p>
            </div>
            <a href="#" class="text-sm text-sky-600 hover:text-sky-500 font-medium">查看全部 →</a>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-sky-50">
              <div class="relative h-52 overflow-hidden">
                <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="https://images.unsplash.com/photo-1584646098378-0874589d76b1?auto=format&fit=crop&w=800&q=80" onerror="this.onerror=null;this.src='https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Forbidden%20City%20Beijing%20red%20walls%20golden%20roofs%20blue%20sky%20travel%20photography&image_size=landscape_4_3'" alt="故宫">
                <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur text-white text-xs">🏛️ 历史文化</span>
              </div>
              <div class="p-5">
                <div class="flex items-center justify-between mb-1.5">
                  <h4 class="text-lg font-bold text-slate-800">故宫博物院</h4>
                  <span class="flex items-center gap-1 text-amber-500 text-sm font-semibold">★ 4.9</span>
                </div>
                <p class="text-sm text-slate-500 leading-relaxed">明清皇家宫殿，世界现存最大木质古建筑群，六百年的皇城记忆。</p>
                <div class="mt-4 flex items-center justify-between text-sm">
                  <span class="text-sky-600 font-bold">¥60 <span class="text-xs font-normal text-slate-400">起</span></span>
                  <span class="text-xs text-slate-400">2.3万条评价</span>
                </div>
              </div>
            </div>
            <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-sky-50">
              <div class="relative h-52 overflow-hidden">
                <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="https://images.unsplash.com/photo-1508804185872-d7badad00f7d?auto=format&fit=crop&w=800&q=80" onerror="this.onerror=null;this.src='https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Great%20Wall%20of%20China%20winding%20over%20mountains%20sunlight%20travel%20photography&image_size=landscape_4_3'" alt="长城">
                <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur text-white text-xs">⛰️ 世界遗产</span>
              </div>
              <div class="p-5">
                <div class="flex items-center justify-between mb-1.5">
                  <h4 class="text-lg font-bold text-slate-800">八达岭长城</h4>
                  <span class="flex items-center gap-1 text-amber-500 text-sm font-semibold">★ 4.8</span>
                </div>
                <p class="text-sm text-slate-500 leading-relaxed">不到长城非好汉，登高远眺，感受千年历史的雄伟壮阔。</p>
                <div class="mt-4 flex items-center justify-between text-sm">
                  <span class="text-sky-600 font-bold">¥40 <span class="text-xs font-normal text-slate-400">起</span></span>
                  <span class="text-xs text-slate-400">1.8万条评价</span>
                </div>
              </div>
            </div>
            <div class="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-sky-50">
              <div class="relative h-52 overflow-hidden">
                <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" src="https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=800&q=80" onerror="this.onerror=null;this.src='https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Summer%20Palace%20Beijing%20Kunming%20lake%20Chinese%20pavilion%20travel%20photography&image_size=landscape_4_3'" alt="颐和园">
                <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur text-white text-xs">🌿 皇家园林</span>
              </div>
              <div class="p-5">
                <div class="flex items-center justify-between mb-1.5">
                  <h4 class="text-lg font-bold text-slate-800">颐和园</h4>
                  <span class="flex items-center gap-1 text-amber-500 text-sm font-semibold">★ 4.8</span>
                </div>
                <p class="text-sm text-slate-500 leading-relaxed">保存最完整的皇家园林，昆明湖与万寿山相映成趣，四季皆景。</p>
                <div class="mt-4 flex items-center justify-between text-sm">
                  <span class="text-sky-600 font-bold">¥30 <span class="text-xs font-normal text-slate-400">起</span></span>
                  <span class="text-xs text-slate-400">1.5万条评价</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="max-w-6xl mx-auto px-6 pb-20">
          <div class="flex items-end justify-between mb-6">
            <div>
              <h3 class="text-2xl font-bold text-slate-800">旅行者说</h3>
              <p class="text-sm text-slate-400 mt-1">来自社区的真实分享</p>
            </div>
            <button @click="addComment()" class="text-sm px-4 py-2 rounded-full bg-sky-500 text-white hover:bg-sky-400 transition font-medium">✏️ 写评论</button>
          </div>
          <div id="comment-list" class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
              <div class="flex items-center gap-3 mb-3">
                <span class="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-blue-500 flex items-center justify-center text-white font-bold">雪</span>
                <div>
                  <p class="font-semibold text-slate-800 text-sm">雪山飞狐</p>
                  <p class="text-xs text-slate-400">2 小时前 · 北京</p>
                </div>
                <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
              </div>
              <p class="text-sm text-slate-600 leading-relaxed">AI 排的故宫行程太省心了！避开了人流高峰，还推荐了角楼咖啡，拍照绝了📸</p>
            </div>
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
              <div class="flex items-center gap-3 mb-3">
                <span class="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold">风</span>
                <div>
                  <p class="font-semibold text-slate-800 text-sm">风之旅人</p>
                  <p class="text-xs text-slate-400">昨天 · 上海</p>
                </div>
                <span class="ml-auto text-amber-400 text-xs">★★★★★</span>
              </div>
              <p class="text-sm text-slate-600 leading-relaxed">长城那天预报有雨，AI 自动把行程调到了上午，下午果然下雨了，神预测！</p>
            </div>
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-sky-50 hover:shadow-md transition">
              <div class="flex items-center gap-3 mb-3">
                <span class="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">桃</span>
                <div>
                  <p class="font-semibold text-slate-800 text-sm">桃桃乌龙</p>
                  <p class="text-xs text-slate-400">3 天前 · 广州</p>
                </div>
                <span class="ml-auto text-amber-400 text-xs">★★★★☆</span>
              </div>
              <p class="text-sm text-slate-600 leading-relaxed">颐和园傍晚的昆明湖美到失语，跟着 AI 推荐的路线走，一步冤枉路都没多走。</p>
            </div>
          </div>
        </section>

        <footer class="border-t border-sky-100 bg-white/60">
          <div class="max-w-6xl mx-auto px-6 py-8 flex items-center justify-between text-sm text-slate-400">
            <span>© 2026 AI旅行行程规划助手</span>
            <div class="flex gap-6">
              <a href="#" class="hover:text-sky-600 transition">关于我们</a>
              <a href="#" class="hover:text-sky-600 transition">帮助中心</a>
              <a href="#" class="hover:text-sky-600 transition">联系我们</a>
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!-- 页面 3：核心业务页（行程详情） -->
    <div id="page-detail" class="page">
      <div class="min-h-screen bg-sky-50/70">
        <nav class="sticky top-0 z-20 bg-white/85 backdrop-blur-md border-b border-sky-100 shadow-sm">
          <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <button @click="go('home')" class="flex items-center gap-1.5 text-sky-600 hover:text-sky-500 font-medium transition">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
              返回首页
            </button>
            <span class="font-bold text-slate-700">行程详情</span>
            <button class="text-sm px-4 py-1.5 rounded-full border border-sky-300 text-sky-600 hover:bg-sky-50 transition">分享行程</button>
          </div>
        </nav>

        <main class="max-w-7xl mx-auto px-6 py-8 flex flex-col lg:flex-row gap-6 items-stretch">
          <section class="lg:w-3/5 relative rounded-2xl overflow-hidden border border-slate-200 shadow-md min-h-[70vh]" style="background: linear-gradient(135deg,#e2e8f0 0%,#cbd5e1 100%);">
            <div class="absolute inset-0 opacity-30" style="background-image:linear-gradient(#94a3b8 1px,transparent 1px),linear-gradient(90deg,#94a3b8 1px,transparent 1px);background-size:48px 48px;"></div>
            <svg class="absolute inset-0 w-full h-full" viewBox="0 0 600 600" preserveAspectRatio="none">
              <path d="M120,180 C200,120 300,260 380,220 S480,380 420,460" fill="none" stroke="#38bdf8" stroke-width="4" stroke-dasharray="10 8" stroke-linecap="round"/>
            </svg>
            <div class="absolute" style="left:20%;top:30%">
              <span class="absolute -inset-3 bg-sky-400/40 rounded-full animate-ping"></span>
              <span class="relative block w-5 h-5 bg-sky-500 rounded-full border-2 border-white shadow-lg"></span>
              <span class="absolute left-6 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">📍 故宫博物院</span>
            </div>
            <div class="absolute" style="left:63%;top:37%">
              <span class="relative block w-4 h-4 bg-amber-400 rounded-full border-2 border-white shadow"></span>
              <span class="absolute left-5 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">🦆 烤鸭店</span>
            </div>
            <div class="absolute" style="left:70%;top:77%">
              <span class="relative block w-4 h-4 bg-emerald-500 rounded-full border-2 border-white shadow"></span>
              <span class="absolute left-5 -top-1 whitespace-nowrap bg-white/95 text-xs font-medium text-slate-700 px-2.5 py-1 rounded-lg shadow">⛰️ 景山公园</span>
            </div>
            <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <svg class="w-14 h-14 text-slate-400/70 mb-3" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
              </svg>
              <p class="text-slate-500 text-lg font-medium tracking-widest">地图加载区</p>
            </div>
            <div class="absolute right-4 top-4 flex flex-col bg-white rounded-lg shadow-md overflow-hidden">
              <button class="w-9 h-9 text-slate-600 hover:bg-sky-50 hover:text-sky-600 font-bold transition">＋</button>
              <div class="h-px bg-slate-100"></div>
              <button class="w-9 h-9 text-slate-600 hover:bg-sky-50 hover:text-sky-600 font-bold transition">－</button>
            </div>
            <div class="absolute left-4 bottom-4 bg-white/90 backdrop-blur rounded-lg shadow px-4 py-2.5 text-xs text-slate-600">
              <p class="font-semibold text-slate-800 mb-1">Day 1 路线</p>
              <p class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-sky-500"></span>故宫 → <span class="w-2 h-2 rounded-full bg-amber-400"></span>烤鸭 → <span class="w-2 h-2 rounded-full bg-emerald-500"></span>景山</p>
            </div>
          </section>

          <section class="lg:w-2/5 bg-white rounded-2xl shadow-md border border-sky-100 p-6 flex flex-col">
            <div class="flex items-start justify-between">
              <div>
                <h2 class="text-2xl font-bold text-slate-800">北京三日游 <span class="bg-gradient-to-r from-sky-500 to-blue-500 bg-clip-text text-transparent text-lg">（AI定制）</span></h2>
                <p class="text-xs text-slate-400 mt-1">10月13日 - 10月15日 · 2人出行 · 已为你节省 ¥320</p>
              </div>
              <span class="shrink-0 px-2.5 py-1 rounded-full bg-sky-100 text-sky-600 text-xs font-semibold">AI 已优化</span>
            </div>

            <div class="mt-4 flex items-center gap-2.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 text-sky-700 text-sm rounded-xl px-4 py-3">
              <span class="text-lg">🌦️</span>
              <span id="weather-tip">今日小雨转阴 18~23°C，AI已调整<strong>室内景点优先</strong></span>
            </div>

            <div class="mt-5 space-y-3 flex-1">
              <div class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
                <button @click="toggleDay(1)" class="w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r from-sky-500 to-blue-500 text-white">
                  <span class="font-semibold flex items-center gap-2">Day 1 · 皇城文化线
                    <span class="text-xs font-normal bg-white/20 px-2 py-0.5 rounded-full">3 个地点</span>
                  </span>
                  <span id="arrow-1" class="acc-arrow rotate-180">▾</span>
                </button>
                <div id="day-1" class="acc-body" style="max-height: 500px;">
                  <ul class="divide-y divide-sky-50">
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">09:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-sky-400 ring-4 ring-sky-100"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">故宫博物院</p><p class="text-xs text-slate-400 mt-0.5">建议游览 3 小时 · 室内优先 · 已预约门票</p></div>
                      <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥60</span>
                    </li>
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">12:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-amber-400 ring-4 ring-amber-50"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">烤鸭午餐（四季民福）</p><p class="text-xs text-slate-400 mt-0.5">人均 ¥120 · 已取号 · 步行 8 分钟</p></div>
                      <span class="text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-lg">美食</span>
                    </li>
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">14:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-4 ring-emerald-50"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">景山公园</p><p class="text-xs text-slate-400 mt-0.5">登顶俯瞰故宫全景 · 视天气灵活调整</p></div>
                      <span class="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">¥2</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
                <button @click="toggleDay(2)" class="w-full flex items-center justify-between px-5 py-4 bg-white hover:bg-sky-50 text-slate-700 transition">
                  <span class="font-semibold flex items-center gap-2">Day 2 · 长城雄关线
                    <span class="text-xs font-normal text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">2 个地点</span>
                  </span>
                  <span id="arrow-2" class="acc-arrow text-slate-400">▾</span>
                </button>
                <div id="day-2" class="acc-body" style="max-height: 0;">
                  <ul class="divide-y divide-sky-50">
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">08:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-sky-400 ring-4 ring-sky-100"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">八达岭长城</p><p class="text-xs text-slate-400 mt-0.5">缆车上下 · 建议穿防滑鞋 · 车程约 1.5h</p></div>
                      <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥40</span>
                    </li>
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">15:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-4 ring-emerald-50"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">奥林匹克公园</p><p class="text-xs text-slate-400 mt-0.5">鸟巢 / 水立方夜景 · 免费</p></div>
                      <span class="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">免费</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div class="border border-sky-100 rounded-xl overflow-hidden shadow-sm">
                <button @click="toggleDay(3)" class="w-full flex items-center justify-between px-5 py-4 bg-white hover:bg-sky-50 text-slate-700 transition">
                  <span class="font-semibold flex items-center gap-2">Day 3 · 园林休闲线
                    <span class="text-xs font-normal text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">2 个地点</span>
                  </span>
                  <span id="arrow-3" class="acc-arrow text-slate-400">▾</span>
                </button>
                <div id="day-3" class="acc-body" style="max-height: 0;">
                  <ul class="divide-y divide-sky-50">
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">09:30</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-sky-400 ring-4 ring-sky-100"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">颐和园</p><p class="text-xs text-slate-400 mt-0.5">昆明湖游船视天气开放 · 建议游览 4 小时</p></div>
                      <span class="text-xs text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">¥30</span>
                    </li>
                    <li class="px-5 py-4 flex items-center gap-4 hover:bg-sky-50/60 transition">
                      <span class="text-sky-600 font-mono font-bold w-14">14:00</span>
                      <div class="flex flex-col items-center"><span class="w-2.5 h-2.5 rounded-full bg-amber-400 ring-4 ring-amber-50"></span></div>
                      <div class="flex-1"><p class="font-medium text-slate-800">南锣鼓巷</p><p class="text-xs text-slate-400 mt-0.5">胡同漫步 · 特色小吃打卡</p></div>
                      <span class="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">免费</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="mt-6 flex gap-4">
              <button @click="regenerate($event)" class="flex-1 py-3.5 rounded-xl border-2 border-sky-400 text-sky-600 font-semibold hover:bg-sky-50 active:scale-[0.98] transition">
                🔄 重新生成
              </button>
              <button @click="alert('已为你打开导航，Day 1 全程步行约 3.2km 🚶')" class="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-400 hover:to-blue-400 text-white font-semibold shadow-lg shadow-sky-300/50 hover:shadow-xl active:scale-[0.98] transition">
                🧭 一键导航
              </button>
            </div>
          </section>
        </main>
      </div>
    </div>
  </div>
</template>

<style scoped>
  /* 页面切换控制 */
  .page { display: none; }
  .page.active { display: block; }
  /* 手风琴折叠动画 */
  .acc-body { overflow: hidden; transition: max-height .4s ease; }
  .acc-arrow { transition: transform .3s ease; }
  /* 登录页雪山背景 */
  .login-bg {
    background-image:
      linear-gradient(rgba(6,16,38,.35), rgba(6,16,38,.55)),
      url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80'),
      linear-gradient(180deg,#060d1f,#123a63);
    background-size: cover;
    background-position: center;
  }
  /* 卡片图片加载失败时隐藏破图 */
  img { background: #e0f2fe; }
</style>
